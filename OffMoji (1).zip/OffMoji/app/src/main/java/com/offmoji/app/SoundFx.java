package com.offmoji.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Phát tiếng mõ / chuông. Thứ tự ưu tiên cho mỗi âm:
 * 1) file người dùng chọn trong app (files/snd_knock, files/snd_bell),
 * 2) file đóng sẵn trong app: res/raw/knock.* và res/raw/bell.* (.wav/.mp3/.ogg),
 * 3) âm tự tổng hợp (SfxSynth).
 */
final class SoundFx {
    private SoundPool pool;
    private int knock;
    private int bell;
    private File knockSynth;
    private File bellSynth;

    SoundFx(final Context c) {
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
            knockSynth = ensure(c, "sfx_knock_v1.wav", SfxSynth.knock());
            bellSynth = ensure(c, "sfx_bell_v1.wav", SfxSynth.bell());

            // file không giải mã được -> quay về âm tự tổng hợp
            pool.setOnLoadCompleteListener((p, id, status) -> {
                if (status != 0 && pool != null) {
                    if (id == knock) knock = pool.load(knockSynth.getPath(), 1);
                    else if (id == bell) bell = pool.load(bellSynth.getPath(), 1);
                }
            });

            knock = loadOne(c, "knock", "snd_knock", knockSynth);
            bell = loadOne(c, "bell", "snd_bell", bellSynth);
        } catch (Exception e) {
            pool = null;
        }
    }

    private int loadOne(Context c, String rawName, String customName, File synth) {
        File custom = new File(c.getFilesDir(), customName);
        if (custom.exists() && custom.length() > 0) return pool.load(custom.getPath(), 1);
        int resId = c.getResources().getIdentifier(rawName, "raw", c.getPackageName());
        if (resId != 0) return pool.load(c, resId, 1);
        return pool.load(synth.getPath(), 1);
    }

    private static File ensure(Context c, String name, byte[] data) throws IOException {
        File f = new File(c.getCacheDir(), name);
        if (!f.exists() || f.length() != data.length) {
            FileOutputStream o = new FileOutputStream(f);
            o.write(data);
            o.close();
        }
        return f;
    }

    void play(boolean isBell, float vol) {
        if (pool != null) pool.play(isBell ? bell : knock, vol, vol, 1, 0, 1f);
    }

    void release() {
        if (pool != null) {
            pool.release();
            pool = null;
        }
    }
}
