package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.nio.ByteBuffer;

/**
 * Xoá nền. Ưu tiên mô hình AI tách người (ML Kit, mô hình nằm sẵn trong app, chạy offline).
 * Nếu không chạy được thì dùng cách tách nền đơn sắc từ mép ảnh.
 */
final class Cutout {
    private Cutout() {}

    interface Callback {
        void done(Bitmap cut, boolean usedFallback);
    }

    static void remove(final Bitmap square, final Callback cb) {
        try {
            SelfieSegmenterOptions opt = new SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                    .build();
            final Segmenter seg = Segmentation.getClient(opt);
            InputImage img = InputImage.fromBitmap(square, 0);
            seg.process(img)
                    .addOnSuccessListener(mask -> {
                        Bitmap out;
                        boolean fb = false;
                        try {
                            out = applyMask(square, mask);
                        } catch (Exception e) {
                            out = flood(square);
                            fb = true;
                        }
                        seg.close();
                        cb.done(out, fb);
                    })
                    .addOnFailureListener(e -> {
                        seg.close();
                        cb.done(flood(square), true);
                    });
        } catch (Throwable t) {
            cb.done(flood(square), true);
        }
    }

    private static Bitmap applyMask(Bitmap square, SegmentationMask mask) {
        int w = mask.getWidth();
        int h = mask.getHeight();
        Bitmap src = (w == square.getWidth() && h == square.getHeight())
                ? square : Bitmap.createScaledBitmap(square, w, h, true);
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        ByteBuffer buf = mask.getBuffer();
        buf.rewind();
        for (int i = 0; i < px.length; i++) {
            float conf = buf.getFloat();
            int a;
            if (conf < 0.3f) a = 0;
            else if (conf > 0.7f) a = 255;
            else a = (int) ((conf - 0.3f) / 0.4f * 255f);
            px[i] = (a << 24) | (px[i] & 0x00FFFFFF);
        }
        Bitmap out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        if (w != square.getWidth() || h != square.getHeight()) {
            out = Bitmap.createScaledBitmap(out, square.getWidth(), square.getHeight(), true);
        }
        return out;
    }

    /** Tách nền đơn sắc: loang từ mép ảnh qua các điểm có màu gần màu nền. */
    private static Bitmap flood(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);

        long sr = 0, sg = 0, sb = 0;
        int cnt = 0;
        int[][] corners = {{0, 0}, {w - 8, 0}, {0, h - 8}, {w - 8, h - 8}};
        for (int[] cc : corners) {
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int p = px[(cc[1] + y) * w + cc[0] + x];
                    sr += Color.red(p);
                    sg += Color.green(p);
                    sb += Color.blue(p);
                    cnt++;
                }
            }
        }
        int br = (int) (sr / cnt);
        int bg = (int) (sg / cnt);
        int bb = (int) (sb / cnt);

        boolean[] isBg = new boolean[w * h];
        int[] queue = new int[w * h];
        int head = 0;
        int tail = 0;
        for (int x = 0; x < w; x++) {
            tail = seed(px, isBg, queue, tail, x, 0, w, br, bg, bb);
            tail = seed(px, isBg, queue, tail, x, h - 1, w, br, bg, bb);
        }
        for (int y = 0; y < h; y++) {
            tail = seed(px, isBg, queue, tail, 0, y, w, br, bg, bb);
            tail = seed(px, isBg, queue, tail, w - 1, y, w, br, bg, bb);
        }
        while (head < tail) {
            int idx = queue[head++];
            int x = idx % w;
            int y = idx / w;
            if (x > 0) tail = seed(px, isBg, queue, tail, x - 1, y, w, br, bg, bb);
            if (x < w - 1) tail = seed(px, isBg, queue, tail, x + 1, y, w, br, bg, bb);
            if (y > 0) tail = seed(px, isBg, queue, tail, x, y - 1, w, br, bg, bb);
            if (y < h - 1) tail = seed(px, isBg, queue, tail, x, y + 1, w, br, bg, bb);
        }
        for (int i = 0; i < px.length; i++) {
            if (isBg[i]) px[i] = 0;
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
    }

    private static int seed(int[] px, boolean[] isBg, int[] queue, int tail,
                            int x, int y, int w, int br, int bg, int bb) {
        int i = y * w + x;
        if (isBg[i]) return tail;
        int p = px[i];
        int dist = Math.abs(Color.red(p) - br) + Math.abs(Color.green(p) - bg) + Math.abs(Color.blue(p) - bb);
        if (dist < 90) {
            isBg[i] = true;
            queue[tail++] = i;
        }
        return tail;
    }
}
