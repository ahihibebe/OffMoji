package com.offmoji.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Phát âm thanh gõ phím. Hai bộ âm tự tạo: "Gõ mõ + chuông" và "Cạp cạp + bốp".
 * Thứ tự ưu tiên cho mỗi âm:
 * 1. file người dùng chọn trong app (files/snd_knock cho gõ phím, files/snd_bell cho cách/Enter),
 * 2. file đóng sẵn trong app: res/raw/knock.* và res/raw/bell.* (.wav, .mp3, .ogg),
 * 3. âm tự tổng hợp (SfxSynth) theo bộ âm đang chọn.
 */
final class SoundFx {
    private SoundPool pool;
    private int key1;
    private int key2;     // chỉ dùng cho bộ "cạp cạp": luân phiên 2 tiếng
    private int space;
    private boolean alt;
    private File key1Synth;
    private File spaceSynth;

    SoundFx(Context c) {
        try {
            int pack = c.getSharedPreferences("offmoji", Context.MODE_PRIVATE).getInt("snd_pack", 0);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();

            File key2Synth = null;
            if (pack == 1) {
                key1Synth = ensure(c, "sfx_clack0_v1.wav", SfxSynth.clack(0));
                key2Synth = ensure(c, "sfx_clack1_v1.wav", SfxSynth.clack(1));
                spaceSynth = ensure(c, "sfx_pop_v1.wav", SfxSynth.pop());
            } else {
                key1Synth = ensure(c, "sfx_knock_v1.wav", SfxSynth.knock());
                spaceSynth = ensure(c, "sfx_bell_v1.wav", SfxSynth.bell());
            }

            // file không giải mã được -> quay về âm tự tổng hợp
            pool.setOnLoadCompleteListener((p, id, status) -> {
                if (status != 0 && pool != null) {
                    if (id == key1) key1 = pool.load(key1Synth.getPath(), 1);
                    else if (id == space) space = pool.load(spaceSynth.getPath(), 1);
                }
            });

            boolean own1 = hasOwn(c, "knock", "snd_knock");
            key1 = loadOne(c, "knock", "snd_knock", key1Synth);
            if (!own1 && key2Synth != null) key2 = pool.load(key2Synth.getPath(), 1);
            space = loadOne(c, "bell", "snd_bell", spaceSynth);
        } catch (Exception e) {
            pool = null;
        }
    }

    private static boolean hasOwn(Context c, String rawName, String customName) {
        File custom = new File(c.getFilesDir(), customName);
        if (custom.exists() && custom.length() > 0) return true;
        return c.getResources().getIdentifier(rawName, "raw", c.getPackageName()) != 0;
    }

    private int loadOne(Context c, String rawName, String customName, File synth) {
        File custom = new File(c.getFilesDir(), customName);
        if (custom.exists() && custom.length() > 0) return pool.load(custom.getPath(), 1);
        int resId = c.getResources().getIdentifier(rawName, "raw", c.getPackageName());
        if (resId != 0) return pool.load(c, resId, 1);
        return pool.load(synth.getPath(), 1);
    }

    private static File ensure(Context c, String name, byte[] data) throws IOException {
        File f = new File(c.getCacheDir(), name);
        if (!f.exists() || f.length() != data.length) {
            FileOutputStream o = new FileOutputStream(f);
            o.write(data);
            o.close();
        }
        return f;
    }

    /** isSpace = true cho phím cách / Enter, false cho phím thường. */
    void play(boolean isSpace, float vol) {
        if (pool == null) return;
        int id;
        if (isSpace) {
            id = space;
        } else if (key2 != 0) {
            alt = !alt;
            id = alt ? key2 : key1;
        } else {
            id = key1;
        }
        pool.play(id, vol, vol, 1, 0, 1f);
    }

    void release() {
        if (pool != null) {
            pool.release();
            pool = null;
        }
    }
}
