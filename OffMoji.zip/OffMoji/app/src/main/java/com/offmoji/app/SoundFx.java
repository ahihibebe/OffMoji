package com.offmoji.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Phát tiếng mõ / chuông (tự tổng hợp bằng SfxSynth, không cần file âm thanh). */
final class SoundFx {
    private SoundPool pool;
    private int knock;
    private int bell;

    SoundFx(Context c) {
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
            File k = ensure(c, "sfx_knock_v1.wav", SfxSynth.knock());
            File b = ensure(c, "sfx_bell_v1.wav", SfxSynth.bell());
            knock = pool.load(k.getPath(), 1);
            bell = pool.load(b.getPath(), 1);
        } catch (Exception e) {
            pool = null;
        }
    }

    private static File ensure(Context c, String name, byte[] data) throws IOException {
        File f = new File(c.getCacheDir(), name);
        if (!f.exists() || f.length() != data.length) {
            FileOutputStream o = new FileOutputStream(f);
            o.write(data);
            o.close();
        }
        return f;
    }

    void play(boolean isBell, float vol) {
        if (pool != null) pool.play(isBell ? bell : knock, vol, vol, 1, 0, 1f);
    }

    void release() {
        if (pool != null) {
            pool.release();
            pool = null;
        }
    }
}
