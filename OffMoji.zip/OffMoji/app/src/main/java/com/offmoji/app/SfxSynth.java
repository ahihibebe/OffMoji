package com.offmoji.app;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

/** Tự tổng hợp âm thanh (mõ gỗ, chuông) thành file WAV - không cần file âm thanh có sẵn. */
public final class SfxSynth {
    private SfxSynth() {}

    public static final int RATE = 22050;

    /** Tiếng gõ mõ: "cộc" ngắn, khô, hơi rỗng. */
    public static byte[] knock() {
        int n = (int) (RATE * 0.24);
        double[] f = {430, 905, 1480};
        double[] a = {1.0, 0.55, 0.22};
        double[] tau = {0.05, 0.032, 0.02};
        double[] s = new double[n];
        Random r = new Random(7);
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v = 0;
            for (int k = 0; k < f.length; k++) {
                v += a[k] * Math.sin(2 * Math.PI * f[k] * t) * Math.exp(-t / tau[k]);
            }
            v += 0.45 * (r.nextDouble() * 2 - 1) * Math.exp(-t / 0.0025);
            v *= Math.min(1.0, t / 0.0006);
            s[i] = v;
        }
        return wav(s, 0.9);
    }

    /** Tiếng chuông nhỏ: ngân khoảng 1 giây. */
    public static byte[] bell() {
        int n = (int) (RATE * 1.3);
        double base = 1318;
        double[] ratio = {1.0, 2.0, 2.4, 3.0, 4.2, 5.4};
        double[] a = {1.0, 0.5, 0.35, 0.3, 0.18, 0.1};
        double[] tau = {0.5, 0.35, 0.3, 0.22, 0.15, 0.1};
        double[] s = new double[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v = 0;
            for (int k = 0; k < ratio.length; k++) {
                v += a[k] * Math.sin(2 * Math.PI * base * ratio[k] * t) * Math.exp(-t / tau[k]);
            }
            v *= Math.min(1.0, t / 0.001);
            s[i] = v;
        }
        return wav(s, 0.8);
    }

    private static byte[] wav(double[] s, double peak) {
        int n = s.length;
        double max = 1e-9;
        for (double x : s) max = Math.max(max, Math.abs(x));
        int fade = (int) (RATE * 0.005);
        byte[] out = new byte[44 + n * 2];
        ByteBuffer bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
        bb.put(new byte[]{'R', 'I', 'F', 'F'});
        bb.putInt(36 + n * 2);
        bb.put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        bb.putInt(16);
        bb.putShort((short) 1);
        bb.putShort((short) 1);
        bb.putInt(RATE);
        bb.putInt(RATE * 2);
        bb.putShort((short) 2);
        bb.putShort((short) 16);
        bb.put(new byte[]{'d', 'a', 't', 'a'});
        bb.putInt(n * 2);
        for (int i = 0; i < n; i++) {
            double v = s[i] / max * peak;
            if (i > n - fade) v *= (n - i) / (double) fade;
            bb.putShort((short) Math.round(v * 32767));
        }
        return out;
    }
}
