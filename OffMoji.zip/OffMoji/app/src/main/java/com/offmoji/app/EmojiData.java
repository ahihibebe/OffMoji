package com.offmoji.app;

/** Dữ liệu emoji + kaomoji có sẵn trong app (không tải từ mạng). */
public final class EmojiData {
    private EmojiData() {}

    public static final String[] NAMES = {
        "Mặt cười", "Cử chỉ & người", "Tim & ký hiệu", "Động vật & thiên nhiên",
        "Đồ ăn", "Hoạt động", "Du lịch", "Đồ vật", "Kaomoji"
    };

    public static final String[] ICONS = {"😀", "👍", "❤️", "🐶", "🍔", "⚽", "✈️", "💡", "ツ"};

    public static final int KAOMOJI = 8;

    private static final String SMILEYS =
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 "
        + "😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 "
        + "🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 "
        + "😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾";

    private static final String GESTURES =
        "👋 🤚 🖐️ ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 "
        + "✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 👀 👁️ 👅 👄 🙋 🙆 🙅 🙇 🤦 🤷 💁 🙎 🙍 💆 💇 🚶 🏃 💃 🕺 "
        + "👯 🧘 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 👮 👷 💂 🕵️ 👸 🤴 🤶 🎅 🧙 🧚 🧛 🧜 🧝 🦸 🦹 👼";

    private static final String SYMBOLS =
        "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☮️ ✝️ ☯️ 🔥 ✨ 🌟 ⭐ 💫 ⚡ 💥 💢 "
        + "💦 💨 💬 💭 💤 ✅ ❌ ❎ ❓ ❗ ‼️ ⁉️ ⚠️ 🚫 ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔶 🔷 ♻️ ➕ ➖ ➗ ✔️ "
        + "➡️ ⬅️ ⬆️ ⬇️ ↗️ 🔝 🔜 🆗 🆕 🆒 🆓 💯 🔔 🎵 🎶 ♾️ ©️ ®️ ™️";

    private static final String ANIMALS =
        "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐽 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 "
        + "🦄 🐝 🐛 🦋 🐌 🐞 🐜 🕷️ 🦂 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 "
        + "🐪 🐫 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🕊️ 🐇 🐁 🐀 🐿️ 🦔 🐾 🐉 🌵 🎄 🌲 🌳 🌴 "
        + "🌱 🌿 ☘️ 🍀 🎍 🍃 🍂 🍁 🍄 🌾 💐 🌷 🌹 🥀 🌺 🌸 🌼 🌻 🌞 🌝 🌛 🌜 🌚 🌕 🌙 🌎 ☁️ ⛅ ⛈️ 🌈 ☔ ❄️ ☃️ 🌊";

    private static final String FOOD =
        "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 "
        + "🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🥠 🍢 🍡 🍧 🍨 "
        + "🍦 🥧 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🍶 🍾 🍷 🍸 🍹 🍺 🍻 🥂 🥃 🥤 🥢 🍽️ 🍴 🥄";

    private static final String ACTIVITY =
        "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🥋 ⛳ 🎣 🎽 🛹 🎿 ⛷️ 🏂 🏋️ 🤸 🤺 🏇 🧗 🏄 🏊 🚴 🏆 🥇 🥈 "
        + "🥉 🏅 🎖️ 🎫 🎟️ 🎪 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🎲 🎯 🎳 🎮 🎰 🧩 🎁 🎀 🎊 🎉 🎈 🧨 "
        + "🧧 🎆 🎇 🏮";

    private static final String TRAVEL =
        "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 "
        + "🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚁 🚀 🛸 🛰️ ⛵ 🛥️ 🚤 ⛴️ 🚢 ⚓ ⛽ 🚧 🚦 🚥 🗺️ 🗿 🗽 🗼 🏰 "
        + "🏯 🏟️ 🎡 🎢 🎠 ⛲ ⛱️ 🏖️ 🏝️ ⛰️ 🏔️ 🗻 🌋 🏕️ ⛺ 🏠 🏡 🏢 🏣 🏥 🏦 🏨 🏪 🏫 🏬 🏭 🕌 ⛪ "
        + "🌅 🌄 🌠 🌇 🌆 🏙️ 🌃 🌌 🌉 🌁";

    private static final String OBJECTS =
        "⌚ 📱 📲 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💽 💾 💿 📀 📷 📸 📹 🎥 📞 ☎️ 📟 📠 📺 📻 🎙️ ⏰ ⏳ ⌛ 📡 🔋 🔌 💡 "
        + "🔦 🕯️ 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🔫 💣 🔪 🗡️ 🛡️ 🔮 💈 🔭 🔬 💊 "
        + "💉 🌡️ 🚽 🚿 🛁 🔑 🗝️ 🚪 🛋️ 🛏️ 🧸 🖼️ 🛍️ 🛒 📦 ✉️ 📧 📨 📝 📁 📅 📌 📍 📎 ✂️ 🔒 🔓 "
        + "🔍 🏷️ 📖 📚 🔖";

    private static final String KAOMOJI_RAW =
        "(◕‿◕)|(╯°□°)╯︵ ┻━┻|¯\\_(ツ)_/¯|(づ｡◕‿‿◕｡)づ|ʕ•ᴥ•ʔ|(ಥ﹏ಥ)|( ͡° ͜ʖ ͡°)|(≧▽≦)|(☞ﾟヮﾟ)☞|"
        + "☜(ﾟヮﾟ☜)|(•‿•)|(¬‿¬)|(＾▽＾)|(´･ω･`)|(｡♥‿♥｡)|٩(◕‿◕)۶|(ง •̀_•́)ง|(ノಠ益ಠ)ノ|(┛◉Д◉)┛|"
        + "(⌐■_■)|(╥﹏╥)|\\(^o^)/|m(_ _)m|(｀・ω・´)|(^_^)v|orz|(´∀`)|(*^‿^*)|(=^･ω･^=)|(＞﹏＜)";

    /** Danh sách ký tự của nhóm thứ index (0..8). Emoji tách bằng dấu cách, kaomoji tách bằng '|'. */
    public static String[] category(int index) {
        switch (index) {
            case 0: return SMILEYS.split(" ");
            case 1: return GESTURES.split(" ");
            case 2: return SYMBOLS.split(" ");
            case 3: return ANIMALS.split(" ");
            case 4: return FOOD.split(" ");
            case 5: return ACTIVITY.split(" ");
            case 6: return TRAVEL.split(" ");
            case 7: return OBJECTS.split(" ");
            default: return KAOMOJI_RAW.split("\\|");
        }
    }
}
