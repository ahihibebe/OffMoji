package com.offmoji.app;

import java.text.Normalizer;

/** Bộ gõ Telex: chuyển chuỗi phím thô (vd "Vieetj") thành chữ tiếng Việt ("Việt"). */
public final class Telex {
    private Telex() {}

    // 12 nguyên âm x 6 dấu: ngang, sắc, huyền, hỏi, ngã, nặng
    private static final String[] TABLE = {
        "aáàảãạ", "ăắằẳẵặ", "âấầẩẫậ", "eéèẻẽẹ", "êếềểễệ", "iíìỉĩị",
        "oóòỏõọ", "ôốồổỗộ", "ơớờởỡợ", "uúùủũụ", "ưứừửữự", "yýỳỷỹỵ"
    };

    static {
        for (int i = 0; i < TABLE.length; i++) {
            TABLE[i] = Normalizer.normalize(TABLE[i], Normalizer.Form.NFC);
        }
    }

    private static int vowelIndex(char c) {
        for (int i = 0; i < TABLE.length; i++) {
            if (TABLE[i].charAt(0) == c) return i;
        }
        return -1;
    }

    private static boolean isVowel(char c) {
        return vowelIndex(c) >= 0;
    }

    private static int toneOf(char l) {
        switch (l) {
            case 's': return 1;
            case 'f': return 2;
            case 'r': return 3;
            case 'x': return 4;
            case 'j': return 5;
            case 'z': return 0;
            default: return -1;
        }
    }

    private static char circumflex(char c) {
        if (c == 'a') return 'â';
        if (c == 'e') return 'ê';
        return 'ô';
    }

    private static char plainOfCircumflex(char c) {
        if (c == 'â') return 'a';
        if (c == 'ê') return 'e';
        return 'o';
    }

    public static String convert(String raw) {
        int cap = raw.length() + 4;
        char[] ch = new char[cap];
        boolean[] up = new boolean[cap];
        int n = 0;
        int tone = 0;
        boolean lock = false;
        int standaloneW = -1;

        for (int k = 0; k < raw.length(); k++) {
            char c = raw.charAt(k);
            boolean isUp = Character.isUpperCase(c);
            char l = Character.toLowerCase(c);

            // --- phím dấu thanh ---
            int t = toneOf(l);
            if (t >= 0 && !lock && hasVowel(ch, n)) {
                if (l == 'z') {
                    if (tone != 0) { tone = 0; continue; }
                } else if (tone == t) {
                    tone = 0;
                    lock = true;
                    ch[n] = l; up[n] = isUp; n++;
                    continue;
                } else {
                    tone = t;
                    continue;
                }
            }

            // --- phím w ---
            if (l == 'w') {
                int i = n - 1;
                int skipped = 0;
                while (i >= 0 && !isVowel(ch[i]) && skipped < 3) { i--; skipped++; }
                if (i >= 0 && isVowel(ch[i])) {
                    char cur = ch[i];
                    if (cur == 'a') {
                        ch[i] = 'ă';
                    } else if (cur == 'o') {
                        ch[i] = 'ơ';
                        if (i > 0 && ch[i - 1] == 'u' && !(i > 1 && ch[i - 2] == 'q')) ch[i - 1] = 'ư';
                    } else if (cur == 'u') {
                        ch[i] = 'ư';
                        if (i + 1 < n && ch[i + 1] == 'o') ch[i + 1] = 'ơ';
                    } else if (cur == 'ă' || cur == 'ơ' || cur == 'ư') {
                        // bấm w lần nữa: huỷ dấu, giữ chữ w
                        if (cur == 'ă') ch[i] = 'a';
                        else if (cur == 'ơ') {
                            ch[i] = 'o';
                            if (i > 0 && ch[i - 1] == 'ư') ch[i - 1] = 'u';
                        } else if (i == standaloneW) {
                            ch[i] = 'w';   // "ww" -> "w"
                            continue;
                        } else {
                            ch[i] = 'u';
                            if (i + 1 < n && ch[i + 1] == 'ơ') ch[i + 1] = 'o';
                        }
                        ch[n] = 'w'; up[n] = isUp; n++;
                    } else {
                        ch[n] = 'w'; up[n] = isUp; n++;
                    }
                } else {
                    // không có nguyên âm: w -> ư
                    standaloneW = n;
                    ch[n] = 'ư'; up[n] = isUp; n++;
                }
                continue;
            }

            // --- aa, ee, oo ---
            if ((l == 'a' || l == 'e' || l == 'o') && n > 0) {
                char last = ch[n - 1];
                if (last == l) {
                    ch[n - 1] = circumflex(l);
                    continue;
                }
                if ((last == 'â' || last == 'ê' || last == 'ô') && plainOfCircumflex(last) == l) {
                    ch[n - 1] = l;
                    ch[n] = l; up[n] = isUp; n++;
                    continue;
                }
            }

            // --- dd ---
            if (l == 'd' && n > 0) {
                if (ch[n - 1] == 'd') { ch[n - 1] = 'đ'; continue; }
                if (ch[n - 1] == 'đ') {
                    ch[n - 1] = 'd';
                    ch[n] = 'd'; up[n] = isUp; n++;
                    continue;
                }
            }

            ch[n] = l; up[n] = isUp; n++;
        }

        // chuẩn hoá: "ưo" -> "ươ"
        for (int i = 0; i + 1 < n; i++) {
            if (ch[i] == 'ư' && ch[i + 1] == 'o') ch[i + 1] = 'ơ';
        }

        int tonePos = tone > 0 ? findTonePos(ch, n) : -1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            String s = glyph(ch[i], i == tonePos ? tone : 0);
            if (up[i]) s = s.toUpperCase();
            sb.append(s);
        }
        return sb.toString();
    }

    private static boolean hasVowel(char[] ch, int n) {
        for (int i = 0; i < n; i++) if (isVowel(ch[i])) return true;
        return false;
    }

    private static String glyph(char c, int tone) {
        int idx = vowelIndex(c);
        if (idx < 0) return String.valueOf(c);
        return TABLE[idx].substring(tone, tone + 1);
    }

    private static boolean modified(char c) {
        return c == 'ă' || c == 'â' || c == 'ê' || c == 'ô' || c == 'ơ' || c == 'ư';
    }

    private static int findTonePos(char[] ch, int n) {
        boolean[] v = new boolean[n];
        for (int i = 0; i < n; i++) v[i] = isVowel(ch[i]);
        // "qu" + nguyên âm: u là phụ âm; "gi" + nguyên âm: i là phụ âm
        if (n > 2 && ch[0] == 'q' && ch[1] == 'u' && v[2]) v[1] = false;
        if (n > 2 && ch[0] == 'g' && ch[1] == 'i' && v[2]) v[1] = false;

        int e = n - 1;
        while (e >= 0 && !v[e]) e--;
        if (e < 0) return -1;
        int s = e;
        while (s > 0 && v[s - 1]) s--;
        int len = e - s + 1;
        if (len == 1) return s;

        // ưu tiên nguyên âm có dấm: ê, ơ, ô, â, ă rồi ư
        char[] order = {'ê', 'ơ', 'ô', 'â', 'ă', 'ư'};
        for (char o : order) {
            for (int i = s; i <= e; i++) if (ch[i] == o) return i;
        }

        // toàn nguyên âm thường
        if (len == 2) {
            boolean finalConsonant = e < n - 1;
            return finalConsonant ? s + 1 : s;
        }
        return s + 1;
    }
}
