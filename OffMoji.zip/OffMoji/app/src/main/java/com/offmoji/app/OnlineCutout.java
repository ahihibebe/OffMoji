package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Xoá nền online qua remove.bg (cần API key). CHỈ chạy khi người dùng bấm "Xoá nền" ở chế độ Online;
 * ảnh vuông 512 px của sticker được gửi lên máy chủ remove.bg, không gửi gì khác.
 */
final class OnlineCutout {
    private OnlineCutout() {}

    interface Callback {
        /** cut != null khi thành công; ngược lại error là thông báo cho người dùng. */
        void done(Bitmap cut, String error);
    }

    static void remove(final Bitmap square, final String apiKey, final Callback cb) {
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            Bitmap result = null;
            String err = null;
            HttpURLConnection conn = null;
            try {
                ByteArrayOutputStream jpg = new ByteArrayOutputStream();
                Bitmap flat = Bitmap.createBitmap(square.getWidth(), square.getHeight(), Bitmap.Config.ARGB_8888);
                android.graphics.Canvas fc = new android.graphics.Canvas(flat);
                fc.drawColor(0xFFFFFFFF);
                fc.drawBitmap(square, 0, 0, null);
                flat.compress(Bitmap.CompressFormat.JPEG, 92, jpg);

                String boundary = "----offmoji" + System.currentTimeMillis();
                URL url = new URL("https://api.remove.bg/v1.0/removebg");
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("X-Api-Key", apiKey);
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

                DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                field(out, boundary, "size", "auto");
                field(out, boundary, "format", "png");
                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"image_file\"; filename=\"sticker.jpg\"\r\n");
                out.writeBytes("Content-Type: image/jpeg\r\n\r\n");
                out.write(jpg.toByteArray());
                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
                out.close();

                int code = conn.getResponseCode();
                if (code == 200) {
                    InputStream in = conn.getInputStream();
                    byte[] data = readAll(in);
                    in.close();
                    Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length);
                    if (b == null) {
                        err = "remove.bg trả về dữ liệu không đọc được";
                    } else if (b.getWidth() != square.getWidth() || b.getHeight() != square.getHeight()) {
                        result = Bitmap.createScaledBitmap(b, square.getWidth(), square.getHeight(), true);
                    } else {
                        result = b;
                    }
                } else if (code == 402) {
                    err = "Đã hết lượt xoá nền miễn phí của remove.bg";
                } else if (code == 403) {
                    err = "API key remove.bg không đúng";
                } else if (code == 429) {
                    err = "Gửi quá nhanh, hãy thử lại sau ít giây";
                } else {
                    err = "remove.bg báo lỗi (mã " + code + ")";
                }
            } catch (Exception e) {
                err = "Không kết nối được mạng để xoá nền online";
            } finally {
                if (conn != null) conn.disconnect();
            }
            final Bitmap fr = result;
            final String fe = err;
            main.post(() -> cb.done(fr, fe));
        }).start();
    }

    private static void field(DataOutputStream out, String boundary, String name, String value) throws Exception {
        out.writeBytes("--" + boundary + "\r\n");
        out.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        out.writeBytes(value + "\r\n");
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int r;
        while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        return bo.toByteArray();
    }
}
