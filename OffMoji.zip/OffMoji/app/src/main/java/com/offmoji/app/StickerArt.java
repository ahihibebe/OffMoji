package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Vẽ sticker: cắt vuông, chữ chú thích, sticker hài hước dựng sẵn. */
final class StickerArt {
    private StickerArt() {}

    static Bitmap cropSquare(Bitmap src, int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        float s = Math.max((float) size / src.getWidth(), (float) size / src.getHeight());
        float dw = src.getWidth() * s;
        float dh = src.getHeight() * s;
        RectF dst = new RectF((size - dw) / 2f, (size - dh) / 2f, (size + dw) / 2f, (size + dh) / 2f);
        c.drawBitmap(src, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    static void drawCaption(Canvas c, String text, int size, boolean top) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        float s = size / 512f;
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextAlign(Paint.Align.CENTER);
        float maxW = 470 * s;
        float sz = 80 * s;
        tp.setTextSize(sz);

        String[] lines = {t};
        if (tp.measureText(t) > maxW) {
            int mid = t.length() / 2;
            int best = -1;
            for (int i = 0; i < t.length(); i++) {
                if (t.charAt(i) == ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
            }
            if (best > 0) lines = new String[]{t.substring(0, best).trim(), t.substring(best + 1).trim()};
        }
        while (sz > 18 * s) {
            tp.setTextSize(sz);
            float widest = 0;
            for (String l : lines) widest = Math.max(widest, tp.measureText(l));
            if (widest <= maxW) break;
            sz -= 2 * s;
        }
        tp.setTextSize(sz);
        Paint stroke = new Paint(tp);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(sz / 6f);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(Color.BLACK);
        tp.setColor(Color.WHITE);

        float lh = sz * 1.1f;
        int n = lines.length;
        for (int i = 0; i < n; i++) {
            float y;
            if (top) y = 16 * s - tp.ascent() + i * lh;
            else y = size - 20 * s - tp.descent() - (n - 1 - i) * lh;
            c.drawText(lines[i], size / 2f, y, stroke);
            c.drawText(lines[i], size / 2f, y, tp);
        }
    }

    private static int lighter(int color) {
        int r = Color.red(color) + (255 - Color.red(color)) * 35 / 100;
        int g = Color.green(color) + (255 - Color.green(color)) * 35 / 100;
        int b = Color.blue(color) + (255 - Color.blue(color)) * 35 / 100;
        return Color.rgb(r, g, b);
    }

    static Bitmap renderFunny(int idx, int size) {
        float s = size / 512f;
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        int color = FunnyData.COLOR[idx];

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, size, lighter(color), color, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, size, size), 72 * s, 72 * s, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(8 * s);
        p.setColor(0x66FFFFFF);
        c.drawRoundRect(new RectF(14 * s, 14 * s, size - 14 * s, size - 14 * s), 60 * s, 60 * s, p);

        Paint ep = new Paint(Paint.ANTI_ALIAS_FLAG);
        ep.setTextSize(240 * s);
        ep.setTextAlign(Paint.Align.CENTER);
        c.drawText(FunnyData.EMOJI[idx], size / 2f, 285 * s, ep);

        drawCaption(c, FunnyData.CAPTION[idx], size, false);
        return bm;
    }
}
