package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.FaceDetector;

/** Vẽ sticker: cắt vuông, chữ chú thích, kiểu tóc, sticker hài hước, viền trắng kiểu Facebook. */
final class StickerArt {
    private StickerArt() {}

    static final String[] HAIR_NAMES = {"Không", "Ngắn", "Dài", "Xoăn", "Búi", "Mohawk", "Bob"};
    static final String[] HAIR_COLOR_NAMES = {"Đen", "Nâu", "Vàng", "Hồng", "Xanh", "Bạc", "Đỏ"};
    static final int[] HAIR_COLORS = {
        0xFF1B1B1B, 0xFF6D4C41, 0xFFF2C94C, 0xFFFF6FA5, 0xFF3DA5FF, 0xFFCFD8DC, 0xFFD32F2F
    };

    // ------------------------------------------------------------------ ảnh

    static Bitmap cropSquare(Bitmap src, int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        float s = Math.max((float) size / src.getWidth(), (float) size / src.getHeight());
        float dw = src.getWidth() * s;
        float dh = src.getHeight() * s;
        RectF dst = new RectF((size - dw) / 2f, (size - dh) / 2f, (size + dw) / 2f, (size + dh) / 2f);
        c.drawBitmap(src, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    /** Viền trắng quanh hình đã tách nền (giống sticker Facebook/Messenger). */
    static Bitmap outlined(Bitmap cut) {
        int w = cut.getWidth();
        int h = cut.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint white = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        white.setColorFilter(new PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN));
        float[] radii = {w * 0.012f, w * 0.022f};
        for (float r : radii) {
            for (int a = 0; a < 360; a += 20) {
                double rad = Math.toRadians(a);
                c.drawBitmap(cut, (float) (Math.cos(rad) * r), (float) (Math.sin(rad) * r), white);
            }
        }
        c.drawBitmap(cut, 0, 0, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    // ------------------------------------------------------------------ chữ

    static void drawCaption(Canvas c, String text, int size, boolean top) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        float s = size / 512f;
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextAlign(Paint.Align.CENTER);
        float maxW = 470 * s;
        float sz = 80 * s;
        tp.setTextSize(sz);

        String[] lines = {t};
        if (tp.measureText(t) > maxW) {
            int mid = t.length() / 2;
            int best = -1;
            for (int i = 0; i < t.length(); i++) {
                if (t.charAt(i) == ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
            }
            if (best > 0) lines = new String[]{t.substring(0, best).trim(), t.substring(best + 1).trim()};
        }
        while (sz > 18 * s) {
            tp.setTextSize(sz);
            float widest = 0;
            for (String l : lines) widest = Math.max(widest, tp.measureText(l));
            if (widest <= maxW) break;
            sz -= 2 * s;
        }
        tp.setTextSize(sz);
        Paint stroke = new Paint(tp);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(sz / 6f);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(Color.BLACK);
        tp.setColor(Color.WHITE);

        float lh = sz * 1.1f;
        int n = lines.length;
        for (int i = 0; i < n; i++) {
            float y;
            if (top) y = 16 * s - tp.ascent() + i * lh;
            else y = size - 20 * s - tp.descent() - (n - 1 - i) * lh;
            c.drawText(lines[i], size / 2f, y, stroke);
            c.drawText(lines[i], size / 2f, y, tp);
        }
    }

    // ------------------------------------------------------------------ sticker hài hước

    private static int lighter(int color) {
        int r = Color.red(color) + (255 - Color.red(color)) * 35 / 100;
        int g = Color.green(color) + (255 - Color.green(color)) * 35 / 100;
        int b = Color.blue(color) + (255 - Color.blue(color)) * 35 / 100;
        return Color.rgb(r, g, b);
    }

    private static int darker(int color) {
        return Color.rgb(Color.red(color) * 6 / 10, Color.green(color) * 6 / 10, Color.blue(color) * 6 / 10);
    }

    static Bitmap renderFunny(int idx, int size) {
        float s = size / 512f;
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        int color = FunnyData.COLOR[idx];

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, size, lighter(color), color, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, size, size), 72 * s, 72 * s, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(8 * s);
        p.setColor(0x66FFFFFF);
        c.drawRoundRect(new RectF(14 * s, 14 * s, size - 14 * s, size - 14 * s), 60 * s, 60 * s, p);

        Paint ep = new Paint(Paint.ANTI_ALIAS_FLAG);
        ep.setTextSize(240 * s);
        ep.setTextAlign(Paint.Align.CENTER);
        c.drawText(FunnyData.EMOJI[idx], size / 2f, 285 * s, ep);

        drawCaption(c, FunnyData.CAPTION[idx], size, false);
        return bm;
    }

    // ------------------------------------------------------------------ khuôn mặt + kiểu tóc

    /** Trả về {tâm hai mắt x, y, khoảng cách hai mắt} hoặc null nếu không thấy mặt. */
    static float[] detectFace(Bitmap square) {
        try {
            Bitmap b = square.copy(Bitmap.Config.RGB_565, false);
            if (b == null) return null;
            FaceDetector fd = new FaceDetector(b.getWidth(), b.getHeight(), 1);
            FaceDetector.Face[] faces = new FaceDetector.Face[1];
            int n = fd.findFaces(b, faces);
            if (n > 0 && faces[0] != null) {
                PointF mid = new PointF();
                faces[0].getMidPoint(mid);
                float d = faces[0].eyesDistance();
                if (d > 10) return new float[]{mid.x, mid.y, d};
            }
        } catch (Exception ignored) {
            // không dò được mặt: dùng vị trí mặc định
        }
        return null;
    }

    private static Path cap(float cx, float cy, float d) {
        float hw = 1.15f * d;
        float l = cx - hw;
        float r = cx + hw;
        float top = cy - 1.45f * d;
        Path p = new Path();
        p.moveTo(l, cy - 0.35f * d);
        p.cubicTo(l - 0.1f * d, cy - 1.3f * d, cx - 0.7f * d, top - 0.15f * d, cx, top - 0.15f * d);
        p.cubicTo(cx + 0.7f * d, top - 0.15f * d, r + 0.1f * d, cy - 1.3f * d, r, cy - 0.35f * d);
        p.cubicTo(r - 0.05f * d, cy - 0.7f * d, cx + 0.5f * d, cy - 0.95f * d, cx + 0.1f * d, cy - 0.85f * d);
        p.cubicTo(cx - 0.3f * d, cy - 0.7f * d, cx - 0.7f * d, cy - 0.95f * d, l, cy - 0.35f * d);
        p.close();
        return p;
    }

    /** Dải tóc rũ hai bên má. sign = -1 (trái) hoặc +1 (phải). */
    private static Path panel(float cx, float cy, float d, int sign, float len) {
        float edge = cx + sign * 1.15f * d;
        float out = sign * 0.55f * d;
        Path p = new Path();
        p.moveTo(edge - sign * 0.05f * d, cy - 0.6f * d);
        p.cubicTo(edge + out, cy, edge + out * 0.9f, cy + len * 0.7f, edge + sign * 0.2f * d, cy + len);
        p.lineTo(edge - sign * 0.3f * d, cy + len * 0.92f);
        p.cubicTo(edge - sign * 0.1f * d, cy + len * 0.5f, edge - sign * 0.05f * d, cy + 0.2f * d,
                edge - sign * 0.05f * d, cy - 0.6f * d);
        p.close();
        return p;
    }

    private static void shape(Canvas c, Path p, Paint fill, Paint line) {
        c.drawPath(p, fill);
        c.drawPath(p, line);
    }

    static void drawHair(Canvas c, int style, int color, float cx, float cy, float d) {
        if (style <= 0) return;
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(color);
        fill.setStyle(Paint.Style.FILL);
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setColor(darker(color));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(2f, d * 0.05f));
        line.setStrokeJoin(Paint.Join.ROUND);

        float top = cy - 1.45f * d;

        switch (style) {
            case 1: // ngắn
                shape(c, cap(cx, cy, d), fill, line);
                break;
            case 2: // dài
                shape(c, panel(cx, cy, d, -1, 2.3f * d), fill, line);
                shape(c, panel(cx, cy, d, 1, 2.3f * d), fill, line);
                shape(c, cap(cx, cy, d), fill, line);
                break;
            case 3: { // xoăn
                c.save();
                Path face = new Path();
                face.addOval(new RectF(cx - 0.98f * d, cy - 0.95f * d, cx + 0.98f * d, cy + 1.7f * d),
                        Path.Direction.CW);
                c.clipOutPath(face);
                for (int k = 0; k < 9; k++) {
                    double ang = Math.toRadians(190 + k * 20);
                    float x = (float) (cx + Math.cos(ang) * 1.15f * d);
                    float y = (float) (cy - 0.5f * d + Math.sin(ang) * 1.3f * d);
                    c.drawCircle(x, y, 0.55f * d, fill);
                }
                c.drawCircle(cx, cy - 0.7f * d, 1.0f * d, fill);
                c.restore();
                break;
            }
            case 4: // búi
                c.drawCircle(cx, top - 0.3f * d, 0.5f * d, fill);
                c.drawCircle(cx, top - 0.3f * d, 0.5f * d, line);
                shape(c, cap(cx, cy, d), fill, line);
                break;
            case 5: { // mohawk
                Path base = new Path();
                base.addOval(new RectF(cx - 0.6f * d, top + 0.05f * d, cx + 0.6f * d, top + 0.45f * d),
                        Path.Direction.CW);
                shape(c, base, fill, line);
                for (int k = -2; k <= 2; k++) {
                    float x = cx + k * 0.24f * d;
                    float h = (1.0f - Math.abs(k) * 0.18f) * d;
                    Path t = new Path();
                    t.moveTo(x - 0.16f * d, top + 0.25f * d);
                    t.lineTo(x, top - h);
                    t.lineTo(x + 0.16f * d, top + 0.25f * d);
                    t.close();
                    shape(c, t, fill, line);
                }
                break;
            }
            case 6: { // bob
                shape(c, panel(cx, cy, d, -1, 1.2f * d), fill, line);
                shape(c, panel(cx, cy, d, 1, 1.2f * d), fill, line);
                shape(c, cap(cx, cy, d), fill, line);
                Path bangs = new Path();
                bangs.addRoundRect(new RectF(cx - 1.05f * d, cy - 1.05f * d, cx + 1.05f * d, cy - 0.6f * d),
                        0.2f * d, 0.2f * d, Path.Direction.CW);
                shape(c, bangs, fill, line);
                break;
            }
            default:
                break;
        }
    }
}
