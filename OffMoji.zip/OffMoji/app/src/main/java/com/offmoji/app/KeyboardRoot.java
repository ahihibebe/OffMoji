package com.offmoji.app;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Khung gốc của bàn phím. Chiều cao CHỈ lấy theo cột phím chính; các lớp phủ (ảnh nền, trái tim)
 * được ép đúng bằng kích thước đó. Nếu không, lớp phủ match_parent sẽ làm cửa sổ bàn phím cao
 * bằng cả màn hình và bàn phím bị nhảy lên đầu.
 */
final class KeyboardRoot extends FrameLayout {
    private View main;

    KeyboardRoot(Context c) {
        super(c);
    }

    void setMain(View v) {
        main = v;
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        if (main == null) {
            super.onMeasure(widthSpec, heightSpec);
            return;
        }
        int w = resolveSize(MeasureSpec.getSize(widthSpec), widthSpec);
        main.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        int h = main.getMeasuredHeight();
        setMeasuredDimension(w, h);
        int ws = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY);
        int hs = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY);
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            if (c != main) c.measure(ws, hs);
        }
    }
}
