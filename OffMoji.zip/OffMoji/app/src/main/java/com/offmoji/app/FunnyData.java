package com.offmoji.app;

/** Danh sách sticker hài hước dựng sẵn (vẽ bằng code, không cần ảnh, không cần mạng). */
public final class FunnyData {
    private FunnyData() {}

    public static final String[] EMOJI = {
        "😏", "😭", "🤣", "😴", "🤡", "💸", "🥲", "🥴", "🙏", "😎",
        "👌", "🔥", "🙈", "🍿", "😤", "🥺", "🤷", "🐶", "😱", "🤐",
        "🥰", "🍚", "🛌", "😈", "🧐", "☀️", "🌙", "💐", "🧧", "🤗"
    };

    public static final String[] CAPTION = {
        "Quỳnh ak?", "Quỳnh ơi cứu!", "Cười xỉu", "Ngủ đi nha", "Tui là chú hề", "Hết tiền rồi",
        "Ổn mà… không ổn", "Choáng luôn", "Xin lỗi nha", "Chấp hết", "Ok luôn", "Đỉnh của chóp",
        "Hổng thấy gì hết", "Ngồi xem drama", "Quạu rồi nha", "Thương thì nói thương", "Bó tay", "Gâu gâu",
        "Trời ơi đất hỡi", "Cạn lời", "Iu quá trời", "Đi ăn cơm", "Mệt quá nghỉ", "Hư lắm nha",
        "Quỳnh nghĩ sao?", "Chào buổi sáng", "Ngủ ngon nha", "Cảm ơn nha", "Chúc mừng năm mới", "Ôm cái nè"
    };

    public static final int[] COLOR = {
        0xFFFF7043, 0xFF5C6BC0, 0xFFFFB300, 0xFF3949AB, 0xFFE53935, 0xFF43A047,
        0xFF8E24AA, 0xFF00ACC1, 0xFFFB8C00, 0xFF1E88E5, 0xFF7CB342, 0xFFD81B60,
        0xFF6D4C41, 0xFF546E7A, 0xFFEF5350, 0xFFEC407A, 0xFF26A69A, 0xFFA1887F,
        0xFF5E35B1, 0xFF78909C, 0xFFFF5252, 0xFFF9A825, 0xFF3F51B5, 0xFF6A1B9A,
        0xFFFF8A65, 0xFFFFA726, 0xFF283593, 0xFF2E7D32, 0xFFC62828, 0xFFAB47BC
    };
}
