package com.offmoji.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Mở hộp thoại nhận giọng nói của hệ thống rồi trả chữ về bàn phím.
 * App không cần quyền micro hay Internet; việc nhận diện do dịch vụ giọng nói của máy đảm nhiệm.
 */
public class VoiceActivity extends Activity {

    /** Chữ vừa nhận diện, bàn phím sẽ lấy và chèn vào ô nhập. */
    static String pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String lang = getIntent().getStringExtra("lang");
        if (lang == null) lang = "vi-VN";
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hãy nói…");
        try {
            startActivityForResult(i, 1);
        } catch (Exception e) {
            Toast.makeText(this, "Máy chưa có dịch vụ nhận diện giọng nói", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) pending = r.get(0);
        }
        finish();
    }
}
