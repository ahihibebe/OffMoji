package com.offmoji.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.view.inputmethod.EditorInfoCompat;
import androidx.core.view.inputmethod.InputConnectionCompat;
import androidx.core.view.inputmethod.InputContentInfoCompat;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Bàn phím OffMoji: gõ Telex, emoji, kiểu chữ, sticker cá nhân. Không dùng mạng. */
public class OffMojiService extends InputMethodService {

    private static final int PANEL_LETTERS = 0;
    private static final int PANEL_EMOJI = 1;
    private static final int PANEL_FONT = 2;
    private static final int PANEL_STICKER = 3;
    private static final int PANEL_H = 214;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder raw = new StringBuilder();
    private final List<TextView> letterKeys = new ArrayList<>();
    private final Map<String, Bitmap> thumbs = new HashMap<>();
    private final Map<Integer, String[]> glyphCache = new HashMap<>();

    private SharedPreferences prefs;
    private float dp = 1f;
    private int themeIdx = -1;
    private int[] C = Themes.COLORS[0];

    private LinearLayout root;
    private FrameLayout content;
    private TextView[] toolViews;
    private TextView shiftKey;
    private TextView spaceKey;
    private ScrollView emojiScroll;

    private int panel = PANEL_LETTERS;
    private int emojiCat = 1;
    private boolean symbols = false;
    private boolean viMode = true;
    private boolean composeAllowed = true;
    private int shift = 0; // 0 tắt, 1 một lần, 2 khoá
    private long lastShiftTap = 0;
    private long lastComposeTs = 0;
    private FontStyles.Style curStyle = null;

    private int px(float d) {
        return Math.round(d * dp);
    }

    // ------------------------------------------------------------------ vòng đời

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public View onCreateInputView() {
        prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
        themeIdx = Math.max(0, Math.min(prefs.getInt("theme", 0), Themes.COLORS.length - 1));
        C = Themes.COLORS[themeIdx];
        viMode = prefs.getBoolean("vi", true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C[0]);
        root.addView(buildToolbar(), new LinearLayout.LayoutParams(MATCH, px(40)));
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(MATCH, px(PANEL_H)));
        panel = PANEL_LETTERS;
        showPanel(PANEL_LETTERS);
        return root;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        raw.setLength(0);

        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        composeAllowed = cls == InputType.TYPE_CLASS_TEXT
                && var != InputType.TYPE_TEXT_VARIATION_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                && var != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                && var != InputType.TYPE_TEXT_VARIATION_URI;

        if (!restarting) {
            symbols = cls == InputType.TYPE_CLASS_NUMBER
                    || cls == InputType.TYPE_CLASS_PHONE
                    || cls == InputType.TYPE_CLASS_DATETIME;
        }

        if (prefs != null && root != null) {
            int t = prefs.getInt("theme", 0);
            if (t != themeIdx) {
                setInputView(onCreateInputView());
            } else if (!restarting) {
                showPanel(PANEL_LETTERS);
            }
        }
        updateAutoCaps();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        raw.setLength(0);
        handler.removeCallbacksAndMessages(null);
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        boolean fresh = SystemClock.uptimeMillis() - lastComposeTs < 200;
        if (raw.length() > 0 && !fresh
                && (candidatesStart == -1 || newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            raw.setLength(0);
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.finishComposingText();
        }
    }

    // ------------------------------------------------------------------ giao diện chung

    private Drawable round(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(6 * dp);
        return g;
    }

    private Drawable keyBg(int normal, int pressed) {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, round(pressed));
        sl.addState(new int[]{}, round(normal));
        return sl;
    }

    private void haptic(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private LinearLayout buildToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(C[3]);
        String[] labels = {"ABC", "😀", "Aa", "🖼", "VI", "🌐", "⌄"};
        toolViews = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(labels[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(16);
            t.setTextColor(C[4]);
            t.setOnClickListener(v -> onToolbarClick(idx, v));
            bar.addView(t, new LinearLayout.LayoutParams(0, MATCH, 1f));
            toolViews[i] = t;
        }
        return bar;
    }

    private void onToolbarClick(int idx, View v) {
        haptic(v);
        switch (idx) {
            case 0: showPanel(PANEL_LETTERS); break;
            case 1: showPanel(PANEL_EMOJI); break;
            case 2: showPanel(PANEL_FONT); break;
            case 3: showPanel(PANEL_STICKER); break;
            case 4:
                commitComposing();
                viMode = !viMode;
                prefs.edit().putBoolean("vi", viMode).apply();
                updateToolbar();
                break;
            case 5:
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
                break;
            default:
                requestHideSelf(0);
        }
    }

    private void updateToolbar() {
        if (toolViews == null) return;
        for (int i = 0; i < 4; i++) toolViews[i].setTextColor(panel == i ? C[5] : C[4]);
        if (curStyle != null) toolViews[2].setTextColor(C[5]);
        toolViews[4].setText(viMode ? "VI" : "EN");
        toolViews[4].setTextColor(viMode ? C[5] : C[4]);
        if (spaceKey != null) spaceKey.setText(spaceLabel());
    }

    private String spaceLabel() {
        if (curStyle != null) return "Kiểu: " + curStyle.name;
        return viMode ? "Tiếng Việt" : "English";
    }

    private void showPanel(int p) {
        commitComposing();
        panel = p;
        thumbs.clear();
        if (content == null) return;
        content.removeAllViews();
        View v;
        switch (p) {
            case PANEL_EMOJI: v = buildEmoji(); break;
            case PANEL_FONT: v = buildFonts(); break;
            case PANEL_STICKER: v = buildStickers(); break;
            default: v = buildLetters();
        }
        content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        updateToolbar();
    }

    // ------------------------------------------------------------------ bàn phím chữ

    private LinearLayout newRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return r;
    }

    private TextView key(String label, float weight, boolean special) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(special ? 16 : 20);
        t.setTextColor(C[4]);
        t.setBackground(keyBg(special ? C[3] : C[1], C[2]));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, weight);
        lp.setMargins(px(2), px(3), px(2), px(3));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView charKey(final String s, final boolean letter) {
        TextView t = key(s, 1f, false);
        if (letter) {
            t.setTag(s);
            letterKeys.add(t);
        }
        t.setOnClickListener(v -> {
            haptic(v);
            onChar(s, letter);
        });
        return t;
    }

    private View spacer(float weight) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, weight));
        return v;
    }

    private View buildLetters() {
        letterKeys.clear();
        shiftKey = null;
        spaceKey = null;

        LinearLayout kb = new LinearLayout(this);
        kb.setOrientation(LinearLayout.VERTICAL);
        kb.setPadding(px(3), px(4), px(3), px(4));

        String[] r0, r1, r2;
        if (symbols) {
            r0 = "1 2 3 4 5 6 7 8 9 0".split(" ");
            r1 = "@ # $ % & - + ( ) /".split(" ");
            r2 = "~ _ * \" ' : ; ! ?".split(" ");
        } else {
            r0 = "q w e r t y u i o p".split(" ");
            r1 = "a s d f g h j k l".split(" ");
            r2 = "z x c v b n m".split(" ");
        }
        boolean letters = !symbols;

        LinearLayout row0 = newRow();
        for (String s : r0) row0.addView(charKey(s, letters));
        kb.addView(row0);

        LinearLayout row1 = newRow();
        if (letters) row1.addView(spacer(0.5f));
        for (String s : r1) row1.addView(charKey(s, letters));
        if (letters) row1.addView(spacer(0.5f));
        kb.addView(row1);

        LinearLayout row2 = newRow();
        if (letters) {
            shiftKey = key("⇧", 1.5f, true);
            shiftKey.setOnClickListener(v -> {
                haptic(v);
                onShift();
            });
            row2.addView(shiftKey);
        }
        for (String s : r2) row2.addView(charKey(s, letters));
        row2.addView(deleteKey());
        kb.addView(row2);

        LinearLayout row3 = newRow();
        TextView sym = key(symbols ? "ABC" : "?123", 1.4f, true);
        sym.setOnClickListener(v -> {
            haptic(v);
            symbols = !symbols;
            showPanel(PANEL_LETTERS);
        });
        row3.addView(sym);
        row3.addView(charKey(",", false));
        spaceKey = key(spaceLabel(), 4f, false);
        spaceKey.setTextSize(14);
        spaceKey.setOnClickListener(v -> {
            haptic(v);
            typeSpace();
        });
        row3.addView(spaceKey);
        row3.addView(charKey(".", false));
        TextView enter = key("⏎", 1.4f, true);
        enter.setOnClickListener(v -> {
            haptic(v);
            doEnter();
        });
        row3.addView(enter);
        kb.addView(row3);

        updateLetterLabels();
        return kb;
    }

    private TextView deleteKey() {
        TextView t = key("⌫", 1.5f, true);
        final Runnable repeat = new Runnable() {
            @Override
            public void run() {
                doDelete();
                handler.postDelayed(this, 55);
            }
        };
        t.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    haptic(v);
                    doDelete();
                    handler.postDelayed(repeat, 400);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    handler.removeCallbacks(repeat);
                    return true;
                default:
                    return true;
            }
        });
        return t;
    }

    private void onShift() {
        long now = SystemClock.uptimeMillis();
        if (shift == 2) {
            shift = 0;
        } else if (shift == 1 && now - lastShiftTap < 400) {
            shift = 2;
        } else {
            shift = (shift == 0) ? 1 : 0;
        }
        lastShiftTap = now;
        updateLetterLabels();
    }

    private void updateLetterLabels() {
        for (TextView t : letterKeys) {
            String s = (String) t.getTag();
            t.setText(shift != 0 ? s.toUpperCase() : s);
        }
        if (shiftKey != null) {
            shiftKey.setText(shift == 2 ? "⇪" : (shift == 1 ? "⬆" : "⇧"));
            shiftKey.setTextColor(shift != 0 ? C[5] : C[4]);
        }
    }

    private void updateAutoCaps() {
        if (shift == 2 || symbols) return;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null || ei.inputType == InputType.TYPE_NULL) return;
        int ns = ic.getCursorCapsMode(ei.inputType) != 0 ? 1 : 0;
        if (ns != shift) {
            shift = ns;
            updateLetterLabels();
        }
    }

    // ------------------------------------------------------------------ nhập liệu

    private void onChar(String s, boolean letter) {
        if (letter) {
            char c = s.charAt(0);
            if (shift != 0) c = Character.toUpperCase(c);
            typeLetter(c);
            if (shift == 1) {
                shift = 0;
                updateLetterLabels();
            }
        } else {
            typeText(s);
        }
    }

    private void typeLetter(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (curStyle != null) {
            ic.commitText(FontStyles.apply(curStyle, String.valueOf(c)), 1);
            return;
        }
        if (viMode && composeAllowed) {
            if (raw.length() >= 40) commitComposing();
            raw.append(c);
            lastComposeTs = SystemClock.uptimeMillis();
            ic.setComposingText(Telex.convert(raw.toString()), 1);
        } else {
            ic.commitText(String.valueOf(c), 1);
        }
    }

    private void commitComposing() {
        if (raw.length() > 0) {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.finishComposingText();
            raw.setLength(0);
        }
    }

    private void typeText(String s) {
        commitComposing();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        updateAutoCaps();
    }

    private void typeSpace() {
        typeText(" ");
    }

    private void doEnter() {
        commitComposing();
        if (!sendDefaultEditorAction(true)) sendKeyChar('\n');
        updateAutoCaps();
    }

    private void doDelete() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (raw.length() > 0) {
            raw.setLength(raw.length() - 1);
            lastComposeTs = SystemClock.uptimeMillis();
            if (raw.length() == 0) {
                ic.commitText("", 1);
            } else {
                ic.setComposingText(Telex.convert(raw.toString()), 1);
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        }
    }

    // ------------------------------------------------------------------ emoji

    private View buildEmoji() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(C[3]);
        LinearLayout cats = new LinearLayout(this);
        cats.setOrientation(LinearLayout.HORIZONTAL);
        final List<TextView> catViews = new ArrayList<>();
        String[] icons = new String[EmojiData.ICONS.length + 1];
        icons[0] = "🕘";
        System.arraycopy(EmojiData.ICONS, 0, icons, 1, EmojiData.ICONS.length);
        for (int i = 0; i < icons.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(icons[i]);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(C[4]);
            t.setOnClickListener(v -> {
                haptic(v);
                emojiCat = idx;
                for (int k = 0; k < catViews.size(); k++) {
                    catViews.get(k).setBackgroundColor(k == emojiCat ? C[2] : 0x00000000);
                }
                fillEmoji();
            });
            t.setBackgroundColor(i == emojiCat ? C[2] : 0x00000000);
            catViews.add(t);
            cats.addView(t, new LinearLayout.LayoutParams(px(46), MATCH));
        }
        hs.addView(cats, new FrameLayout.LayoutParams(WRAP, MATCH));
        box.addView(hs, new LinearLayout.LayoutParams(MATCH, px(40)));

        emojiScroll = new ScrollView(this);
        box.addView(emojiScroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        fillEmoji();
        return box;
    }

    private String[] filterGlyphs(int cat, String[] items) {
        String[] cached = glyphCache.get(cat);
        if (cached != null) return cached;
        Paint p = new Paint();
        List<String> ok = new ArrayList<>();
        for (String s : items) {
            if (p.hasGlyph(s)) ok.add(s);
        }
        String[] result = (ok.size() * 10 < items.length * 4) ? items : ok.toArray(new String[0]);
        glyphCache.put(cat, result);
        return result;
    }

    private void fillEmoji() {
        emojiScroll.removeAllViews();
        boolean recent = emojiCat == 0;
        int cat = emojiCat - 1;
        boolean kao = !recent && cat == EmojiData.KAOMOJI;
        String[] items;
        if (recent) {
            items = recentList();
        } else if (kao) {
            items = EmojiData.category(cat);
        } else {
            items = filterGlyphs(cat, EmojiData.category(cat));
        }

        if (items.length == 0) {
            TextView msg = new TextView(this);
            msg.setText("Chưa có emoji nào dùng gần đây");
            msg.setTextColor(C[4]);
            msg.setGravity(Gravity.CENTER);
            msg.setPadding(px(16), px(40), px(16), px(16));
            emojiScroll.addView(msg);
            return;
        }

        GridLayout g = new GridLayout(this);
        int cols = kao ? 2 : 8;
        g.setColumnCount(cols);
        int cellW = getResources().getDisplayMetrics().widthPixels / cols;
        int cellH = kao ? px(46) : px(48);
        for (String it : items) {
            final String item = it;
            TextView t = new TextView(this);
            t.setText(item);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(C[4]);
            if (kao) {
                t.setTextSize(15);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(px(4), 0, px(4), 0);
            } else {
                t.setTextSize(26);
            }
            t.setBackground(keyBg(0x00000000, C[2]));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cellW;
            lp.height = cellH;
            t.setLayoutParams(lp);
            t.setOnClickListener(v -> {
                haptic(v);
                insertEmoji(item);
            });
            g.addView(t);
        }
        emojiScroll.addView(g);
    }

    private void insertEmoji(String s) {
        commitComposing();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        saveRecent(s);
    }

    private String[] recentList() {
        String r = prefs.getString("recent", "");
        if (r == null || r.isEmpty()) return new String[0];
        return r.split("\n");
    }

    private void saveRecent(String s) {
        List<String> l = new ArrayList<>(Arrays.asList(recentList()));
        l.remove(s);
        l.add(0, s);
        while (l.size() > 32) l.remove(l.size() - 1);
        prefs.edit().putString("recent", TextUtils.join("\n", l)).apply();
    }

    // ------------------------------------------------------------------ kiểu chữ

    private View buildFonts() {
        ScrollView sv = new ScrollView(this);
        GridLayout g = new GridLayout(this);
        g.setColumnCount(2);
        int cellW = getResources().getDisplayMetrics().widthPixels / 2;
        addFontCell(g, null, cellW);
        for (FontStyles.Style s : FontStyles.ALL) addFontCell(g, s, cellW);
        sv.addView(g);
        return sv;
    }

    private void addFontCell(GridLayout g, final FontStyles.Style s, int cellW) {
        String sample = s == null ? "Hello World" : FontStyles.apply(s, "Hello World");
        String name = s == null ? "Mặc định" : s.name;
        SpannableStringBuilder sb = new SpannableStringBuilder(sample + "\n" + name);
        int st = sample.length() + 1;
        sb.setSpan(new RelativeSizeSpan(0.62f), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan(C[5]), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView t = new TextView(this);
        t.setText(sb);
        t.setTextSize(17);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(C[4]);
        t.setBackground(keyBg(curStyle == s ? C[2] : C[1], C[2]));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = cellW - px(6);
        lp.height = px(62);
        lp.setMargins(px(3), px(3), px(3), px(3));
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> {
            haptic(v);
            curStyle = s;
            showPanel(PANEL_LETTERS);
        });
        g.addView(t);
    }

    // ------------------------------------------------------------------ sticker

    private Bitmap thumb(File f) {
        Bitmap b = thumbs.get(f.getPath());
        if (b == null) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b != null) thumbs.put(f.getPath(), b);
        }
        return b;
    }

    private View buildStickers() {
        File[] files = StickerStore.list(this);
        if (files.length == 0) {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setPadding(px(20), px(10), px(20), px(10));

            TextView msg = new TextView(this);
            msg.setText("Chưa có sticker nào.\nMở app OffMoji → mục “Tạo sticker” để làm sticker từ ảnh của bạn.");
            msg.setTextColor(C[4]);
            msg.setTextSize(15);
            msg.setGravity(Gravity.CENTER);
            box.addView(msg, new LinearLayout.LayoutParams(WRAP, WRAP));

            TextView open = new TextView(this);
            open.setText("Mở app OffMoji");
            open.setTextColor(C[4]);
            open.setGravity(Gravity.CENTER);
            open.setPadding(px(20), px(10), px(20), px(10));
            open.setBackground(keyBg(C[1], C[2]));
            open.setOnClickListener(v -> {
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.topMargin = px(12);
            box.addView(open, lp);
            return box;
        }

        ScrollView sv = new ScrollView(this);
        GridLayout g = new GridLayout(this);
        g.setColumnCount(4);
        int cell = getResources().getDisplayMetrics().widthPixels / 4;
        for (File f : files) {
            final File file = f;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(6), px(6), px(6), px(6));
            Bitmap b = thumb(file);
            if (b != null) iv.setImageBitmap(b);
            iv.setBackground(keyBg(0x00000000, C[2]));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnClickListener(v -> {
                haptic(v);
                sendSticker(file);
            });
            g.addView(iv);
        }
        sv.addView(g);
        return sv;
    }

    private boolean acceptsPng(EditorInfo ei) {
        for (String t : EditorInfoCompat.getContentMimeTypes(ei)) {
            if ("image/png".equals(t) || "image/*".equals(t) || "*/*".equals(t)) return true;
        }
        return false;
    }

    private void sendSticker(File f) {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null) return;
        commitComposing();

        Uri uri;
        try {
            uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        } catch (Exception e) {
            Toast.makeText(this, "Không đọc được sticker", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = false;
        if (acceptsPng(ei)) {
            InputContentInfoCompat info = new InputContentInfoCompat(
                    uri, new ClipDescription("sticker", new String[]{"image/png"}), null);
            ok = InputConnectionCompat.commitContent(ic, ei, info,
                    InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null);
        }
        if (!ok) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newUri(getContentResolver(), "sticker", uri));
            }
            Toast.makeText(this,
                    "Ô nhập này không nhận ảnh từ bàn phím. Đã sao chép sticker — hãy giữ ô nhập và chọn Dán.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
