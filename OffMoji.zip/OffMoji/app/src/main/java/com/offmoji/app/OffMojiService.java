package com.offmoji.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.view.inputmethod.EditorInfoCompat;
import androidx.core.view.inputmethod.InputConnectionCompat;
import androidx.core.view.inputmethod.InputContentInfoCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Bàn phím OffMoji: gõ Telex, emoji, kiểu chữ, sticker, hiệu ứng, âm thanh. Không dùng mạng. */
public class OffMojiService extends InputMethodService {

    private static final int PANEL_LETTERS = 0;
    private static final int PANEL_EMOJI = 1;
    private static final int PANEL_FONT = 2;
    private static final int PANEL_STICKER = 3;
    private static final int PANEL_H = 250;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder raw = new StringBuilder();
    private final List<TextView> letterKeys = new ArrayList<>();
    private final Map<String, Bitmap> thumbs = new HashMap<>();
    private final Map<Integer, String[]> glyphCache = new HashMap<>();

    private SharedPreferences prefs;
    private SoundFx sfx;
    private float dp = 1f;
    private int themeIdx = -1;
    private int[] C = Themes.COLORS[0];
    private int style = 0;          // 0 phẳng, 1 kính lỏng, 2 phím nổi
    private int keyAlphaPct = 100;
    private boolean hasBg = false;
    private String builtSig = "";
    private boolean fxHeart = true;
    private boolean fxSound = true;
    private float soundVol = 0.8f;

    private FrameLayout root;
    private FrameLayout content;
    private HeartView hearts;
    private View[] toolViews;
    private TextView shiftKey;
    private TextView spaceKey;
    private ScrollView emojiScroll;

    private int panel = PANEL_LETTERS;
    private int emojiCat = 1;
    private int stickerTab = 0;
    private int symPage = 0;        // 0 chữ, 1 ký tự, 2 ký tự thêm
    private int imMode = 0;         // 0 Telex, 1 VNI, 2 tắt (EN)
    private boolean compat = true;  // gõ bằng xoá+chèn thay vì vùng soạn thảo (ổn định hơn ở Chrome/Facebook/Zalo)
    private String lastDisplay = "";
    private long soundStamp = 0;
    private long lastEditTs = 0;
    private boolean composeAllowed = true;
    private int shift = 0;          // 0 tắt, 1 một lần, 2 khoá
    private long lastShiftTap = 0;
    private FontStyles.Style curStyle = null;

    private int px(float d) {
        return Math.round(d * dp);
    }

    // ------------------------------------------------------------------ vòng đời

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            // cửa sổ bàn phím trong suốt để giao diện kính lỏng nhìn xuyên được xuống ứng dụng phía sau
            Window w = getWindow().getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setFormat(PixelFormat.TRANSLUCENT);
            }
        } catch (Exception ignored) {
            // không chỉnh được cửa sổ: giữ mặc định
        }
        prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        soundStamp = prefs.getLong("snd_stamp", 0);
        sfx = new SoundFx(this);
    }

    @Override
    public void onDestroy() {
        if (sfx != null) sfx.release();
        super.onDestroy();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    private String sig() {
        return prefs.getInt("theme", 0) + "|" + prefs.getInt("key_alpha", 100) + "|"
                + prefs.getInt("bg_alpha", 100) + "|" + prefs.getBoolean("bg_on", false) + "|"
                + prefs.getLong("bg_stamp", 0);
    }

    private void loadFlags() {
        fxHeart = prefs.getBoolean("fx_heart", true);
        fxSound = prefs.getBoolean("fx_sound", true);
        soundVol = prefs.getInt("sound_vol", 80) / 100f;
        imMode = Math.max(0, Math.min(2, prefs.getInt("im_mode", 0)));
        compat = prefs.getBoolean("compat", false);
        long st = prefs.getLong("snd_stamp", 0);
        if (st != soundStamp) {
            soundStamp = st;
            if (sfx != null) sfx.release();
            sfx = new SoundFx(this);
        }
    }

    @Override
    public View onCreateInputView() {
        prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
        builtSig = sig();
        themeIdx = Math.max(0, Math.min(prefs.getInt("theme", 0), Themes.COLORS.length - 1));
        C = Themes.COLORS[themeIdx];
        style = Themes.STYLE[themeIdx];
        keyAlphaPct = Math.max(5, Math.min(100, prefs.getInt("key_alpha", 100)));
        int bgAlpha = Math.max(5, Math.min(100, prefs.getInt("bg_alpha", 100)));
        loadFlags();

        File bgFile = new File(getFilesDir(), "bg.jpg");
        hasBg = prefs.getBoolean("bg_on", false) && bgFile.exists();

        KeyboardRoot kr = new KeyboardRoot(this);
        root = kr;
        root.setClipChildren(false);
        if (style == 1 && !hasBg) {
            root.setBackground(new GlassPanelDrawable(dp));
        } else if (style == 3 && !hasBg) {
            root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, Themes.FUR_BG));
        } else {
            root.setBackgroundColor(C[0]);
        }
        if (hasBg) {
            Bitmap bm = BitmapFactory.decodeFile(bgFile.getPath());
            if (bm != null) {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(bm);
                iv.setAlpha(bgAlpha / 100f);
                root.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
            } else {
                hasBg = false;
            }
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.addView(buildToolbar(), new LinearLayout.LayoutParams(MATCH, px(40)));
        content = new FrameLayout(this);
        content.setClipChildren(false);
        col.addView(content, new LinearLayout.LayoutParams(MATCH, px(PANEL_H)));
        root.addView(col, new FrameLayout.LayoutParams(MATCH, WRAP));
        kr.setMain(col);

        hearts = new HeartView(this);
        root.addView(hearts, new FrameLayout.LayoutParams(MATCH, MATCH));

        panel = PANEL_LETTERS;
        showPanel(PANEL_LETTERS);
        return root;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        resetWord();
        if (prefs == null) prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        loadFlags();

        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        composeAllowed = cls == InputType.TYPE_CLASS_TEXT
                && var != InputType.TYPE_TEXT_VARIATION_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                && var != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                && var != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                && (var != InputType.TYPE_TEXT_VARIATION_URI || prefs.getBoolean("uri_vi", true));

        if (!restarting) {
            boolean numeric = cls == InputType.TYPE_CLASS_NUMBER
                    || cls == InputType.TYPE_CLASS_PHONE
                    || cls == InputType.TYPE_CLASS_DATETIME;
            symPage = numeric ? 1 : 0;
        }

        if (root != null) {
            if (!sig().equals(builtSig)) {
                setInputView(onCreateInputView());
            } else if (!restarting) {
                showPanel(PANEL_LETTERS);
            }
        }
        updateAutoCaps();

        if (VoiceActivity.pending != null) {
            handler.postDelayed(() -> {
                String t = VoiceActivity.pending;
                VoiceActivity.pending = null;
                InputConnection ic = getCurrentInputConnection();
                if (t != null && ic != null) ic.commitText(t + " ", 1);
            }, 250);
        }
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        resetWord();
        handler.removeCallbacksAndMessages(null);
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        if (raw.length() == 0) return;

        boolean lost;
        if (!compat && candidatesStart >= 0 && candidatesEnd >= 0) {
            // ô nhập báo vùng soạn thảo: chỉ coi là mất khi con trỏ rời khỏi vùng đó.
            // (Trình duyệt hay tự chọn thêm phần gợi ý phía sau nên không xét điểm cuối.)
            lost = newSelStart < candidatesStart || newSelStart > candidatesEnd;
        } else {
            // không có thông tin vùng soạn thảo: sự kiện đến sau khi mình đã im lặng khá lâu
            // nghĩa là do bên ngoài đổi (xoá ô, chuyển con trỏ...). Sự kiện trễ do chính mình gõ thì bỏ qua.
            lost = SystemClock.uptimeMillis() - lastEditTs > 800;
        }
        if (lost) {
            InputConnection ic = getCurrentInputConnection();
            if (!compat && ic != null) ic.finishComposingText();
            resetWord();
        }
    }

    // ------------------------------------------------------------------ giao diện chung

    private Drawable keyShape(int color) {
        GradientDrawable g = new GradientDrawable();
        float kf = keyAlphaPct / 100f;
        int a = (color >>> 24);
        g.setColor((((int) (a * kf)) << 24) | (color & 0x00FFFFFF));
        g.setCornerRadius((style == 2 ? 12 : 6) * dp);
        return g;
    }

    private Drawable keyBg(int normal, int pressed) {
        if (style == 1) {
            boolean special = normal == C[3];
            int al = Math.round(255 * keyAlphaPct / 100f);
            CachedDrawable up = new GlassKeyDrawable(special, false, dp);
            CachedDrawable down = new GlassKeyDrawable(special, true, dp);
            up.setAlpha(al);
            down.setAlpha(al);
            StateListDrawable glass = new StateListDrawable();
            glass.addState(new int[]{android.R.attr.state_pressed}, down);
            glass.addState(new int[]{}, up);
            return glass;
        }
        if (style == 3) {
            boolean special = normal == C[3];
            int al = Math.round(255 * keyAlphaPct / 100f);
            CachedDrawable up = new BubbleDrawable(special ? C[3] : normal, false, dp);
            CachedDrawable down = new BubbleDrawable(special ? C[3] : normal, true, dp);
            up.setAlpha(al);
            down.setAlpha(al);
            StateListDrawable bubble = new StateListDrawable();
            bubble.addState(new int[]{android.R.attr.state_pressed}, down);
            bubble.addState(new int[]{}, up);
            return bubble;
        }
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, keyShape(pressed));
        sl.addState(new int[]{}, keyShape(normal));
        return sl;
    }

    /** Ô trong suốt (emoji, sticker): chỉ sáng lên khi chạm. */
    private Drawable cellBg() {
        GradientDrawable on = new GradientDrawable();
        on.setColor((C[2] & 0x00FFFFFF) | 0x99000000);
        on.setCornerRadius(8 * dp);
        GradientDrawable off = new GradientDrawable();
        off.setColor(0x00000000);
        off.setCornerRadius(8 * dp);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, on);
        sl.addState(new int[]{}, off);
        return sl;
    }

    private void haptic(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void playSound(boolean bell) {
        if (fxSound && sfx != null) sfx.play(bell, soundVol);
    }

    private void spawnHeart(View key, String label) {
        if (!fxHeart || hearts == null) return;
        int[] a = new int[2];
        int[] b = new int[2];
        key.getLocationInWindow(a);
        hearts.getLocationInWindow(b);
        hearts.spawn(a[0] - b[0] + key.getWidth() / 2f, a[1] - b[1] + key.getHeight() * 0.3f, label);
    }

    private LinearLayout buildToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        int barColor;
        if (style == 1 || style == 3) barColor = 0x33FFFFFF;
        else if (hasBg) barColor = (C[3] & 0x00FFFFFF) | 0xA0000000;
        else barColor = C[3];
        bar.setBackgroundColor(barColor);
        toolViews = new View[8];
        for (int i = 0; i < 8; i++) {
            final int idx = i;
            View t;
            if (i == 0 || i == 2 || i == 5) {
                TextView tv = new TextView(this);
                tv.setText(i == 0 ? "ABC" : (i == 2 ? "Aa" : "Telex"));
                tv.setGravity(Gravity.CENTER);
                tv.setTextSize(i == 5 ? 12 : 16);
                tv.setTextColor(C[4]);
                t = tv;
            } else {
                ImageView iv = new ImageView(this);
                int res = R.drawable.ic_mic;
                if (i == 1) res = R.drawable.ic_emoji;
                else if (i == 3) res = R.drawable.ic_sticker;
                else if (i == 6) res = R.drawable.ic_globe;
                else if (i == 7) res = R.drawable.ic_hide;
                iv.setImageResource(res);
                iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                iv.setPadding(px(9), px(9), px(9), px(9));
                iv.setColorFilter(C[4]);
                t = iv;
            }
            t.setOnClickListener(v -> onToolbarClick(idx, v));
            bar.addView(t, new LinearLayout.LayoutParams(0, MATCH, 1f));
            toolViews[i] = t;
        }
        return bar;
    }

    private void setToolColor(int i, int color) {
        View v = toolViews[i];
        if (v instanceof TextView) ((TextView) v).setTextColor(color);
        else if (v instanceof ImageView) ((ImageView) v).setColorFilter(color);
    }

    private void onToolbarClick(int idx, View v) {
        haptic(v);
        switch (idx) {
            case 0: showPanel(PANEL_LETTERS); break;
            case 1: showPanel(PANEL_EMOJI); break;
            case 2: showPanel(PANEL_FONT); break;
            case 3: showPanel(PANEL_STICKER); break;
            case 4: startVoice(); break;
            case 5:
                commitComposing();
                imMode = (imMode + 1) % 3;
                prefs.edit().putInt("im_mode", imMode).apply();
                updateToolbar();
                break;
            case 6:
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
                break;
            default:
                requestHideSelf(0);
        }
    }

    private void startVoice() {
        commitComposing();
        Intent i = new Intent(this, VoiceActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("lang", imMode != 2 ? "vi-VN" : "en-US");
        startActivity(i);
    }

    private void updateToolbar() {
        if (toolViews == null) return;
        for (int i = 0; i < 4; i++) setToolColor(i, panel == i ? C[5] : C[4]);
        if (curStyle != null) setToolColor(2, C[5]);
        TextView mode = (TextView) toolViews[5];
        mode.setText(imMode == 0 ? "Telex" : (imMode == 1 ? "VNI" : "EN"));
        mode.setTextColor(imMode != 2 ? C[5] : C[4]);
        if (spaceKey != null) spaceKey.setText(spaceLabel());
    }

    private String spaceLabel() {
        if (curStyle != null) return "Kiểu: " + curStyle.name;
        return imMode == 0 ? "Tiếng Việt (Telex)" : (imMode == 1 ? "Tiếng Việt (VNI)" : "English");
    }

    private void showPanel(int p) {
        commitComposing();
        panel = p;
        thumbs.clear();
        if (content == null) return;
        content.removeAllViews();
        View v;
        switch (p) {
            case PANEL_EMOJI: v = buildEmoji(); break;
            case PANEL_FONT: v = buildFonts(); break;
            case PANEL_STICKER: v = buildStickers(); break;
            default: v = buildLetters();
        }
        content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        updateToolbar();
    }

    // ------------------------------------------------------------------ bàn phím chữ

    private LinearLayout newRow(float height) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setClipChildren(false);
        r.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, height));
        return r;
    }

    private TextView key(String label, float weight, boolean special) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(special ? 16 : 20);
        t.setTextColor(style == 3 && special ? 0xFFFFFFFF : C[4]);
        t.setBackground(keyBg(special ? C[3] : C[1], C[2]));
        if (style == 2) t.setElevation(px(3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, weight);
        int mh = style == 3 ? 1 : (style == 2 ? 3 : 2);
        int mv = style == 3 ? 1 : (style == 2 ? 4 : 3);
        lp.setMargins(px(mh), px(mv), px(mh), px(mv));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView charKey(final String s, final boolean letter) {
        TextView t = key(s, 1f, false);
        if (letter) {
            t.setTag(s);
            letterKeys.add(t);
        }
        t.setOnClickListener(v -> {
            haptic(v);
            onChar(v, s, letter);
        });
        return t;
    }

    private View spacer(float weight) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, weight));
        return v;
    }

    private LinearLayout charRow(String[] keys, boolean letters, float height) {
        LinearLayout row = newRow(height);
        boolean pad = keys.length == 9;
        if (pad) row.addView(spacer(0.5f));
        for (String s : keys) row.addView(charKey(s, letters));
        if (pad) row.addView(spacer(0.5f));
        return row;
    }

    private View buildLetters() {
        letterKeys.clear();
        shiftKey = null;
        spaceKey = null;

        LinearLayout kb = new LinearLayout(this);
        kb.setOrientation(LinearLayout.VERTICAL);
        kb.setClipChildren(false);
        kb.setClipToPadding(false);
        kb.setPadding(px(3), px(3), px(3), px(4));

        boolean letters = symPage == 0;
        String[] rowA;
        String[] rowB;
        String[] rowC;
        if (letters) {
            rowA = "q w e r t y u i o p".split(" ");
            rowB = "a s d f g h j k l".split(" ");
            rowC = "z x c v b n m".split(" ");
        } else if (symPage == 1) {
            rowA = "@ # $ _ & - + ( ) /".split(" ");
            rowB = "% * \" ' : ; ! ? ~".split(" ");
            rowC = "… « » ¿ ¡ ± ¬".split(" ");
        } else {
            rowA = "` | • √ π ÷ × § ¶ ∞".split(" ");
            rowB = "€ £ ¥ ₫ ¢ ^ ° = { }".split(" ");
            rowC = "\\ © ® ™ [ ] < >".split(" ");
        }

        kb.addView(charRow("1 2 3 4 5 6 7 8 9 0".split(" "), false, 0.8f));
        kb.addView(charRow(rowA, letters, 1f));
        kb.addView(charRow(rowB, letters, 1f));

        LinearLayout row2 = newRow(1f);
        if (letters) {
            shiftKey = key("⇧", 1.5f, true);
            shiftKey.setOnClickListener(v -> {
                haptic(v);
                onShift();
            });
            row2.addView(shiftKey);
        } else {
            TextView sw = key(symPage == 1 ? "=\\<" : "?123", 1.5f, true);
            sw.setOnClickListener(v -> {
                haptic(v);
                symPage = symPage == 1 ? 2 : 1;
                showPanel(PANEL_LETTERS);
            });
            row2.addView(sw);
        }
        for (String s : rowC) row2.addView(charKey(s, letters));
        row2.addView(deleteKey());
        kb.addView(row2);

        LinearLayout row3 = newRow(1f);
        TextView mode = key(letters ? "?123" : "ABC", 1.4f, true);
        mode.setOnClickListener(v -> {
            haptic(v);
            symPage = letters ? 1 : 0;
            showPanel(PANEL_LETTERS);
        });
        row3.addView(mode);
        row3.addView(charKey(",", false));

        spaceKey = key(spaceLabel(), 4f, false);
        spaceKey.setTextSize(14);
        spaceKey.setOnTouchListener(new View.OnTouchListener() {
            private float lastX;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = e.getX();
                        moved = false;
                        v.setPressed(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float step = px(16);
                        float dx = e.getX() - lastX;
                        while (dx >= step) {
                            moveCursor(1);
                            lastX += step;
                            dx -= step;
                            moved = true;
                            v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                        }
                        while (dx <= -step) {
                            moveCursor(-1);
                            lastX -= step;
                            dx += step;
                            moved = true;
                            v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        v.setPressed(false);
                        if (!moved) {
                            haptic(v);
                            spawnHeart(v, "");
                            typeSpace();
                            playSound(true);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        return true;
                    default:
                        return true;
                }
            }
        });
        row3.addView(spaceKey);

        row3.addView(charKey(".", false));
        TextView enter = key("⏎", 1.4f, true);
        enter.setOnClickListener(v -> {
            haptic(v);
            playSound(true);
            doEnter();
        });
        row3.addView(enter);
        kb.addView(row3);

        updateLetterLabels();
        return kb;
    }

    private TextView deleteKey() {
        TextView t = key("⌫", 1.5f, true);
        final Runnable repeat = new Runnable() {
            @Override
            public void run() {
                doDelete();
                handler.postDelayed(this, 55);
            }
        };
        t.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    haptic(v);
                    playSound(false);
                    doDelete();
                    handler.postDelayed(repeat, 400);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    handler.removeCallbacks(repeat);
                    return true;
                default:
                    return true;
            }
        });
        return t;
    }

    private void onShift() {
        long now = SystemClock.uptimeMillis();
        if (shift == 2) {
            shift = 0;
        } else if (shift == 1 && now - lastShiftTap < 400) {
            shift = 2;
        } else {
            shift = (shift == 0) ? 1 : 0;
        }
        lastShiftTap = now;
        updateLetterLabels();
    }

    private void updateLetterLabels() {
        for (TextView t : letterKeys) {
            String s = (String) t.getTag();
            t.setText(shift != 0 ? s.toUpperCase() : s);
        }
        if (shiftKey != null) {
            shiftKey.setText(shift == 2 ? "⇪" : (shift == 1 ? "⬆" : "⇧"));
            shiftKey.setTextColor(shift != 0 ? (style == 3 ? 0xFFFFE082 : C[5]) : (style == 3 ? 0xFFFFFFFF : C[4]));
        }
    }

    private void updateAutoCaps() {
        if (shift == 2 || symPage != 0) return;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null || ei.inputType == InputType.TYPE_NULL) return;
        int ns = ic.getCursorCapsMode(ei.inputType) != 0 ? 1 : 0;
        if (ns != shift) {
            shift = ns;
            updateLetterLabels();
        }
    }

    // ------------------------------------------------------------------ nhập liệu

    private void onChar(View v, String s, boolean letter) {
        playSound(false);
        if (letter) {
            char c = s.charAt(0);
            if (shift != 0) c = Character.toUpperCase(c);
            spawnHeart(v, String.valueOf(c));
            typeLetter(c);
            if (shift == 1) {
                shift = 0;
                updateLetterLabels();
            }
        } else if (imMode == 1 && composeAllowed && curStyle == null && raw.length() > 0
                && s.length() == 1 && Character.isDigit(s.charAt(0))) {
            // VNI: số dùng để bỏ dấu khi đang gõ dở một từ
            spawnHeart(v, s);
            typeLetter(s.charAt(0));
        } else {
            spawnHeart(v, s);
            typeText(s);
        }
    }

    private void typeLetter(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (curStyle != null) {
            ic.commitText(FontStyles.apply(curStyle, String.valueOf(c)), 1);
            return;
        }
        if (imMode != 2 && composeAllowed) {
            if (raw.length() >= 40) commitComposing();
            raw.append(c);
            showWord(ic);
        } else {
            ic.commitText(String.valueOf(c), 1);
        }
    }

    private void commitComposing() {
        if (raw.length() > 0) {
            InputConnection ic = getCurrentInputConnection();
            if (!compat && ic != null) ic.finishComposingText();
        }
        resetWord();
    }

    private void resetWord() {
        raw.setLength(0);
        lastDisplay = "";
    }

    /** Hiển thị từ đang gõ (đã đổi dấu) vào ô nhập. */
    private void showWord(InputConnection ic) {
        long now = SystemClock.uptimeMillis();
        if (compat && lastDisplay.length() > 0 && now - lastEditTs > 600) {
            // chế độ tương thích sẽ xoá chữ trước con trỏ: chắc chắn đó đúng là từ đang gõ rồi mới xoá
            CharSequence before = ic.getTextBeforeCursor(lastDisplay.length(), 0);
            if (before != null && !before.toString().equals(lastDisplay)) {
                char last = raw.charAt(raw.length() - 1);
                raw.setLength(0);
                raw.append(last);
                lastDisplay = "";
            }
        }
        lastEditTs = now;
        String disp = Telex.convert(raw.toString(), imMode == 1 ? Telex.VNI : Telex.TELEX);
        if (compat) {
            ic.beginBatchEdit();
            if (lastDisplay.length() > 0) ic.deleteSurroundingText(lastDisplay.length(), 0);
            ic.commitText(disp, 1);
            ic.endBatchEdit();
        } else {
            ic.setComposingText(disp, 1);
        }
        lastDisplay = disp;
    }

    private void clearWord(InputConnection ic) {
        lastEditTs = SystemClock.uptimeMillis();
        if (compat) {
            if (lastDisplay.length() > 0) ic.deleteSurroundingText(lastDisplay.length(), 0);
        } else {
            ic.commitText("", 1);
        }
        lastDisplay = "";
    }

    private void typeText(String s) {
        commitComposing();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        updateAutoCaps();
    }

    private void typeSpace() {
        typeText(" ");
    }

    private void moveCursor(int dir) {
        commitComposing();
        sendDownUpKeyEvents(dir > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT);
    }

    private void doEnter() {
        commitComposing();
        if (!sendDefaultEditorAction(true)) sendKeyChar('\n');
        updateAutoCaps();
    }

    private void doDelete() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (raw.length() > 0) {
            raw.setLength(raw.length() - 1);
            if (raw.length() == 0) {
                clearWord(ic);
            } else {
                showWord(ic);
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        }
    }

    // ------------------------------------------------------------------ emoji

    private View buildEmoji() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cats = new LinearLayout(this);
        cats.setOrientation(LinearLayout.HORIZONTAL);
        final List<TextView> catViews = new ArrayList<>();
        String[] icons = new String[EmojiData.ICONS.length + 1];
        icons[0] = "🕘";
        System.arraycopy(EmojiData.ICONS, 0, icons, 1, EmojiData.ICONS.length);
        for (int i = 0; i < icons.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(icons[i]);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(C[4]);
            t.setOnClickListener(v -> {
                haptic(v);
                emojiCat = idx;
                for (int k = 0; k < catViews.size(); k++) {
                    catViews.get(k).setBackgroundColor(k == emojiCat ? ((C[2] & 0x00FFFFFF) | 0x99000000) : 0x00000000);
                }
                fillEmoji();
            });
            t.setBackgroundColor(i == emojiCat ? ((C[2] & 0x00FFFFFF) | 0x99000000) : 0x00000000);
            catViews.add(t);
            cats.addView(t, new LinearLayout.LayoutParams(px(46), MATCH));
        }
        hs.addView(cats, new FrameLayout.LayoutParams(WRAP, MATCH));
        box.addView(hs, new LinearLayout.LayoutParams(MATCH, px(40)));

        emojiScroll = new ScrollView(this);
        box.addView(emojiScroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        fillEmoji();
        return box;
    }

    private String[] filterGlyphs(int cat, String[] items) {
        String[] cached = glyphCache.get(cat);
        if (cached != null) return cached;
        Paint p = new Paint();
        List<String> ok = new ArrayList<>();
        for (String s : items) {
            if (p.hasGlyph(s)) ok.add(s);
        }
        String[] result = (ok.size() * 10 < items.length * 4) ? items : ok.toArray(new String[0]);
        glyphCache.put(cat, result);
        return result;
    }

    private void fillEmoji() {
        emojiScroll.removeAllViews();
        boolean recent = emojiCat == 0;
        int cat = emojiCat - 1;
        boolean kao = !recent && cat == EmojiData.KAOMOJI;
        String[] items;
        if (recent) {
            items = recentList();
        } else if (kao) {
            items = EmojiData.category(cat);
        } else {
            items = filterGlyphs(cat, EmojiData.category(cat));
        }

        if (items.length == 0) {
            TextView msg = new TextView(this);
            msg.setText("Chưa có emoji nào dùng gần đây");
            msg.setTextColor(C[4]);
            msg.setGravity(Gravity.CENTER);
            msg.setPadding(px(16), px(40), px(16), px(16));
            emojiScroll.addView(msg);
            return;
        }

        GridLayout g = new GridLayout(this);
        int cols = kao ? 2 : 8;
        g.setColumnCount(cols);
        int cellW = getResources().getDisplayMetrics().widthPixels / cols;
        int cellH = kao ? px(46) : px(48);
        for (String it : items) {
            final String item = it;
            TextView t = new TextView(this);
            t.setText(item);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(C[4]);
            if (kao) {
                t.setTextSize(15);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(px(4), 0, px(4), 0);
            } else {
                t.setTextSize(26);
            }
            t.setBackground(cellBg());
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cellW;
            lp.height = cellH;
            t.setLayoutParams(lp);
            t.setOnClickListener(v -> {
                haptic(v);
                playSound(false);
                spawnHeart(v, "");
                insertEmoji(item);
            });
            g.addView(t);
        }
        emojiScroll.addView(g);
    }

    private void insertEmoji(String s) {
        commitComposing();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        saveRecent(s);
    }

    private String[] recentList() {
        String r = prefs.getString("recent", "");
        if (r == null || r.isEmpty()) return new String[0];
        return r.split("\n");
    }

    private void saveRecent(String s) {
        List<String> l = new ArrayList<>(Arrays.asList(recentList()));
        l.remove(s);
        l.add(0, s);
        while (l.size() > 32) l.remove(l.size() - 1);
        prefs.edit().putString("recent", TextUtils.join("\n", l)).apply();
    }

    // ------------------------------------------------------------------ kiểu chữ

    private View buildFonts() {
        ScrollView sv = new ScrollView(this);
        GridLayout g = new GridLayout(this);
        g.setColumnCount(2);
        int cellW = getResources().getDisplayMetrics().widthPixels / 2;
        addFontCell(g, null, cellW);
        for (FontStyles.Style s : FontStyles.ALL) addFontCell(g, s, cellW);
        sv.addView(g);
        return sv;
    }

    private void addFontCell(GridLayout g, final FontStyles.Style s, int cellW) {
        String sample = s == null ? "Hello World" : FontStyles.apply(s, "Hello World");
        String name = s == null ? "Mặc định" : s.name;
        SpannableStringBuilder sb = new SpannableStringBuilder(sample + "\n" + name);
        int st = sample.length() + 1;
        sb.setSpan(new RelativeSizeSpan(0.62f), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan(C[5]), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView t = new TextView(this);
        t.setText(sb);
        t.setTextSize(17);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(C[4]);
        t.setBackground(keyBg(curStyle == s ? C[2] : C[1], C[2]));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = cellW - px(6);
        lp.height = px(62);
        lp.setMargins(px(3), px(3), px(3), px(3));
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> {
            haptic(v);
            curStyle = s;
            showPanel(PANEL_LETTERS);
        });
        g.addView(t);
    }

    // ------------------------------------------------------------------ sticker

    private Bitmap thumb(File f) {
        Bitmap b = thumbs.get(f.getPath());
        if (b == null) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b != null) thumbs.put(f.getPath(), b);
        }
        return b;
    }

    private Bitmap funnyThumb(int i) {
        String k = "fun:" + i;
        Bitmap b = thumbs.get(k);
        if (b == null) {
            b = StickerArt.renderFunny(i, StickerStore.FUNNY_SIZE);
            thumbs.put(k, b);
        }
        return b;
    }

    private File funnyFile(int i) throws Exception {
        return StickerStore.funnyFile(this, i);
    }

    private View buildStickers() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(px(6), px(3), px(6), px(3));
        String[] names = {"Hài hước", "Của tôi"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(14);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(C[4]);
            t.setPadding(px(14), px(4), px(14), px(4));
            t.setBackground(keyBg(stickerTab == i ? C[2] : C[1], C[2]));
            t.setOnClickListener(v -> {
                haptic(v);
                stickerTab = idx;
                showPanel(PANEL_STICKER);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, MATCH);
            lp.setMargins(px(3), px(2), px(3), px(2));
            bar.addView(t, lp);
        }
        box.addView(bar, new LinearLayout.LayoutParams(MATCH, px(42)));
        box.addView(stickerTab == 0 ? buildFunnyStickers() : buildMyStickers(),
                new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return box;
    }

    private View buildMyStickers() {
        File[] files = StickerStore.list(this);
        if (files.length == 0) {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setPadding(px(20), px(10), px(20), px(10));

            TextView msg = new TextView(this);
            msg.setText("Chưa có sticker nào.\nMở app OffMoji → tab “Sticker” để tạo sticker từ ảnh, hoặc chọn mục “Hài hước” ở trên.");
            msg.setTextColor(C[4]);
            msg.setTextSize(14);
            msg.setGravity(Gravity.CENTER);
            box.addView(msg, new LinearLayout.LayoutParams(WRAP, WRAP));

            TextView open = new TextView(this);
            open.setText("Mở app OffMoji");
            open.setTextColor(C[4]);
            open.setGravity(Gravity.CENTER);
            open.setPadding(px(20), px(10), px(20), px(10));
            open.setBackground(keyBg(C[1], C[2]));
            open.setOnClickListener(v -> {
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.topMargin = px(12);
            box.addView(open, lp);
            return box;
        }

        ScrollView sv = new ScrollView(this);
        GridLayout g = new GridLayout(this);
        g.setColumnCount(4);
        int cell = getResources().getDisplayMetrics().widthPixels / 4;
        for (File f : files) {
            final File file = f;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(6), px(6), px(6), px(6));
            Bitmap b = thumb(file);
            if (b != null) iv.setImageBitmap(b);
            iv.setBackground(cellBg());
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnClickListener(v -> {
                haptic(v);
                sendSticker(file);
            });
            g.addView(iv);
        }
        sv.addView(g);
        return sv;
    }

    private View buildFunnyStickers() {
        ScrollView sv = new ScrollView(this);
        GridLayout g = new GridLayout(this);
        g.setColumnCount(4);
        int cell = getResources().getDisplayMetrics().widthPixels / 4;
        for (int i = 0; i < FunnyData.EMOJI.length; i++) {
            final int idx = i;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(5), px(5), px(5), px(5));
            iv.setImageBitmap(funnyThumb(i));
            iv.setBackground(cellBg());
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnClickListener(v -> {
                haptic(v);
                try {
                    sendSticker(funnyFile(idx));
                } catch (Exception e) {
                    Toast.makeText(this, "Không tạo được sticker", Toast.LENGTH_SHORT).show();
                }
            });
            g.addView(iv);
        }
        sv.addView(g);
        return sv;
    }

    private boolean acceptsPng(EditorInfo ei) {
        for (String t : EditorInfoCompat.getContentMimeTypes(ei)) {
            if ("image/png".equals(t) || "image/*".equals(t) || "*/*".equals(t)) return true;
        }
        return false;
    }

    private void sendSticker(File f) {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null) return;
        commitComposing();

        Uri uri;
        try {
            uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        } catch (Exception e) {
            Toast.makeText(this, "Không đọc được sticker", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = false;
        if (acceptsPng(ei)) {
            InputContentInfoCompat info = new InputContentInfoCompat(
                    uri, new android.content.ClipDescription("sticker", new String[]{"image/png"}), null);
            ok = InputConnectionCompat.commitContent(ic, ei, info,
                    InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null);
        }
        if (!ok) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newUri(getContentResolver(), "sticker", uri));
            }
            Toast.makeText(this,
                    "Ô nhập này không nhận ảnh từ bàn phím. Đã sao chép sticker — hãy giữ ô nhập và chọn Dán.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
