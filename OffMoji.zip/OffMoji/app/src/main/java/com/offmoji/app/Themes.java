package com.offmoji.app;

/** Bảng màu bàn phím: {nền, phím, phím khi nhấn, phím chức năng, chữ, màu nhấn}. */
public final class Themes {
    private Themes() {}

    public static final String[] NAMES = {"Tối", "Sáng", "Hồng", "Xanh biển", "Kính lỏng", "Phím nổi"};

    /** 0 = phẳng, 1 = kính lỏng, 2 = phím nổi. */
    public static final int[] STYLE = {0, 0, 0, 0, 1, 2};

    public static final int[][] COLORS = {
        {0xFF1E1F24, 0xFF3A3C45, 0xFF5A5D6B, 0xFF2B2D34, 0xFFFFFFFF, 0xFFFFB300},
        {0xFFD9DCE2, 0xFFFFFFFF, 0xFFC4C8D0, 0xFFB5BAC4, 0xFF111111, 0xFF1A73E8},
        {0xFFFFE3EC, 0xFFFFFFFF, 0xFFFFB8CF, 0xFFFFC2D6, 0xFF4A1020, 0xFFE91E63},
        {0xFF0D2B45, 0xFF1D4E75, 0xFF2F7AB0, 0xFF143A5C, 0xFFFFFFFF, 0xFF4FC3F7},
        {0xFF16233F, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFBFD9FF, 0xFFFFFFFF, 0xFF7FDBFF},
        {0xFFE9EBF2, 0xFFFFFFFF, 0xFFD5D9E6, 0xFFF3F4F9, 0xFF1D2030, 0xFF6C5CE7}
    };

    /** Nền chuyển sắc của giao diện kính lỏng khi chưa chọn ảnh nền. */
    public static final int[] GLASS_BG = {0xFF3A1C71, 0xFF2D4B9B, 0xFF1A8FB5};
}
