package com.offmoji.app;

/** Bảng màu bàn phím: {nền, phím, phím khi nhấn, phím chức năng, chữ, màu nhấn}. */
public final class Themes {
    private Themes() {}

    public static final String[] NAMES = {"Tối", "Sáng", "Hồng", "Xanh biển", "Kính lỏng", "Phím nổi", "Bông"};

    /** 0 = phẳng, 1 = kính lỏng, 2 = phím nổi, 3 = bông (phím phủ lông + nút kính bóng). */
    public static final int[] STYLE = {0, 0, 0, 0, 1, 2, 3};

    public static final int[][] COLORS = {
        {0xFF1E1F24, 0xFF3A3C45, 0xFF5A5D6B, 0xFF2B2D34, 0xFFFFFFFF, 0xFFFFB300},
        {0xFFD9DCE2, 0xFFFFFFFF, 0xFFC4C8D0, 0xFFB5BAC4, 0xFF111111, 0xFF1A73E8},
        {0xFFFFE3EC, 0xFFFFFFFF, 0xFFFFB8CF, 0xFFFFC2D6, 0xFF4A1020, 0xFFE91E63},
        {0xFF0D2B45, 0xFF1D4E75, 0xFF2F7AB0, 0xFF143A5C, 0xFFFFFFFF, 0xFF4FC3F7},
        // kính lỏng: nền gần như trong suốt, phím là kính mờ, chữ đậm để dễ đọc trên mọi nền
        {0x1AFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFD6E6FF, 0xFF0F1B33, 0xFF0A74FF},
        {0xFFE9EBF2, 0xFFFFFFFF, 0xFFD5D9E6, 0xFFF3F4F9, 0xFF1D2030, 0xFF6C5CE7},
        // bông: phím lông màu kem, nút chức năng là kính bóng đỏ
        {0xFFB9B9BF, 0xFFF3E9DC, 0xFFE2D3C0, 0xFFB3262E, 0xFF2B2420, 0xFFE53935}
    };

    /** Nền mờ của kính lỏng khi chưa chọn ảnh nền (trên -> dưới). */
    public static final int[] GLASS_BG = {0x40FFFFFF, 0x18FFFFFF};

    /** Nền của giao diện bông: xám sáng -> xám -> đỏ ở đáy. */
    public static final int[] FUR_BG = {0xFFD2D2D6, 0xFF8F8F96, 0xFFB8323A};
}
