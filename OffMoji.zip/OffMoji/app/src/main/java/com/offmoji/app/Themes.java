package com.offmoji.app;

/** Bảng màu bàn phím: {nền, phím, phím khi nhấn, phím chức năng, chữ, màu nhấn}. */
public final class Themes {
    private Themes() {}

    public static final String[] NAMES = {"Tối", "Sáng", "Hồng", "Xanh biển", "Kính lỏng", "Phím nổi", "Bông"};

    /** 0 = phẳng, 1 = kính lỏng, 2 = phím nổi, 3 = bông (phím tròn đỏ nhạt, nút chức năng đỏ đậm, đều là kính bóng). */
    public static final int[] STYLE = {0, 0, 0, 0, 1, 2, 3};

    public static final int[][] COLORS = {
        {0xFF1E1F24, 0xFF3A3C45, 0xFF5A5D6B, 0xFF2B2D34, 0xFFFFFFFF, 0xFFFFB300},
        {0xFFD9DCE2, 0xFFFFFFFF, 0xFFC4C8D0, 0xFFB5BAC4, 0xFF111111, 0xFF1A73E8},
        {0xFFFFE3EC, 0xFFFFFFFF, 0xFFFFB8CF, 0xFFFFC2D6, 0xFF4A1020, 0xFFE91E63},
        {0xFF0D2B45, 0xFF1D4E75, 0xFF2F7AB0, 0xFF143A5C, 0xFFFFFFFF, 0xFF4FC3F7},
        // kính lỏng: nền gần như trong suốt, phím là kính mờ, chữ đậm để dễ đọc trên mọi nền
        {0x1AFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFD6E6FF, 0xFF0F1B33, 0xFF0A74FF},
        {0xFFE9EBF2, 0xFFFFFFFF, 0xFFD5D9E6, 0xFFF3F4F9, 0xFF1D2030, 0xFF6C5CE7},
        // bông: phím chữ tròn màu đỏ nhạt, nút chức năng đỏ đậm (kính bóng)
        {0xFFB9B9BF, 0xFFF4A3A8, 0xFFE5646C, 0xFFB3262E, 0xFF3A0B10, 0xFFE53935}
    };

    /** Nền của giao diện bông: xám sáng -> xám -> đỏ ở đáy. */
    public static final int[] FUR_BG = {0xFFD2D2D6, 0xFF8F8F96, 0xFFB8323A};
}
