package com.offmoji.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/** Lớp phủ vẽ các trái tim bay lên, bên trong có chữ của phím vừa bấm. Không nhận cảm ứng. */
public final class HeartView extends View {

    private static final class P {
        float x0, y0, size, phase;
        long born;
        int color;
        String ch;
    }

    private static final int[] COLORS = {0xFFFF4D6D, 0xFFFF758F, 0xFFFF2E63, 0xFFFF5C8A, 0xFFE63946, 0xFFFF8FAB};
    private static final long LIFE = 950;

    private final ArrayList<P> ps = new ArrayList<>();
    private final Random rnd = new Random();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint letter = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path unitHeart = new Path();
    private final Path tmp = new Path();
    private final android.graphics.Matrix m = new android.graphics.Matrix();
    private final float dp;

    public HeartView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        setClickable(false);
        setFocusable(false);
        letter.setTextAlign(Paint.Align.CENTER);
        letter.setTypeface(Typeface.DEFAULT_BOLD);
        letter.setColor(0xFFFFFFFF);
        // trái tim đơn vị (rộng ~1.2, cao ~1.1), tâm gần (0,0)
        unitHeart.moveTo(0f, 0.38f);
        unitHeart.cubicTo(-0.95f, -0.05f, -0.55f, -0.78f, 0f, -0.32f);
        unitHeart.cubicTo(0.55f, -0.78f, 0.95f, -0.05f, 0f, 0.38f);
        unitHeart.close();
    }

    /** Tạo một trái tim tại (x, y) tính theo toạ độ của view này. */
    public void spawn(float x, float y, String ch) {
        P p = new P();
        p.x0 = x;
        p.y0 = y;
        p.size = (30 + rnd.nextInt(14)) * dp;
        p.phase = rnd.nextFloat() * 6.28f;
        p.born = SystemClock.uptimeMillis();
        p.color = COLORS[rnd.nextInt(COLORS.length)];
        p.ch = ch == null ? "" : ch;
        if (ps.size() > 36) ps.remove(0);
        ps.add(p);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        Iterator<P> it = ps.iterator();
        while (it.hasNext()) {
            P p = it.next();
            float t = (now - p.born) / (float) LIFE;
            if (t >= 1f) {
                it.remove();
                continue;
            }
            float ease = 1f - (1f - t) * (1f - t);
            float y = p.y0 - 150f * dp * ease;
            float x = p.x0 + (float) Math.sin(p.phase + t * 5f) * 14f * dp;
            float scale = 0.55f + 0.45f * Math.min(1f, t * 5f);
            int alpha = (int) (255 * (1f - t * t));
            float s = p.size * scale;

            m.reset();
            m.postScale(s, s);
            m.postTranslate(x, y);
            tmp.reset();
            unitHeart.transform(m, tmp);
            fill.setColor((p.color & 0x00FFFFFF) | (alpha << 24));
            c.drawPath(tmp, fill);

            if (!p.ch.isEmpty()) {
                letter.setTextSize(s * 0.46f);
                letter.setAlpha(alpha);
                c.drawText(p.ch, x, y - s * 0.03f + s * 0.46f * 0.35f, letter);
            }
        }
        if (!ps.isEmpty()) postInvalidateOnAnimation();
    }
}
