package com.offmoji.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * Lớp phủ hiệu ứng khi gõ: trái tim bay lên có chữ của phím bên trong, và bướm phát sáng
 * bay quanh bàn phím. Không nhận cảm ứng.
 */
public final class HeartView extends View {

    private static final class P {
        float x0, y0, size, phase;
        long born;
        int color;
        String ch;
    }

    private static final class B {
        float x0, y0, vx, vy, size, phase, flapHz;
        long born, life;
        int color;
    }

    private static final int[] COLORS = {0xFFFF4D6D, 0xFFFF758F, 0xFFFF2E63, 0xFFFF5C8A, 0xFFE63946, 0xFFFF8FAB};
    private static final int[] BF_COLORS = {0xFF7DF9FF, 0xFFFF8AD8, 0xFFFFE066, 0xFFB794F6, 0xFF8AFFB0};
    private static final long LIFE = 950;

    private final ArrayList<P> ps = new ArrayList<>();
    private final ArrayList<B> bs = new ArrayList<>();
    private final Random rnd = new Random();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint letter = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wingLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path unitHeart = new Path();
    private final Path tmp = new Path();
    private final Path wingUpper = new Path();
    private final Path wingLower = new Path();
    private final Matrix m = new Matrix();
    private final float dp;

    public HeartView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        setClickable(false);
        setFocusable(false);
        letter.setTextAlign(Paint.Align.CENTER);
        letter.setTypeface(Typeface.DEFAULT_BOLD);
        letter.setColor(0xFFFFFFFF);
        // trái tim đơn vị (rộng ~1.2, cao ~1.1), tâm gần (0,0)
        unitHeart.moveTo(0f, 0.38f);
        unitHeart.cubicTo(-0.95f, -0.05f, -0.55f, -0.78f, 0f, -0.32f);
        unitHeart.cubicTo(0.55f, -0.78f, 0.95f, -0.05f, 0f, 0.38f);
        unitHeart.close();

        // cánh bướm bên phải (đơn vị): cánh trên + cánh dưới; cánh trái lấy đối xứng
        wingUpper.moveTo(0.05f, -0.05f);
        wingUpper.cubicTo(0.35f, -0.95f, 1.25f, -1.05f, 1.05f, -0.25f);
        wingUpper.cubicTo(0.95f, 0.05f, 0.4f, 0.05f, 0.05f, 0f);
        wingUpper.close();
        wingLower.moveTo(0.05f, 0.05f);
        wingLower.cubicTo(0.65f, 0f, 1.0f, 0.45f, 0.7f, 0.85f);
        wingLower.cubicTo(0.45f, 1.05f, 0.12f, 0.65f, 0.05f, 0.15f);
        wingLower.close();

        wing.setStyle(Paint.Style.FILL);
        wingLine.setStyle(Paint.Style.STROKE);
        wingLine.setStrokeWidth(0.05f);
        body.setStyle(Paint.Style.STROKE);
        body.setStrokeWidth(0.11f);
        body.setStrokeCap(Paint.Cap.ROUND);
    }

    /** Tạo một trái tim tại (x, y) tính theo toạ độ của view này. */
    public void spawn(float x, float y, String ch) {
        P p = new P();
        p.x0 = x;
        p.y0 = y;
        p.size = (30 + rnd.nextInt(14)) * dp;
        p.phase = rnd.nextFloat() * 6.28f;
        p.born = SystemClock.uptimeMillis();
        p.color = COLORS[rnd.nextInt(COLORS.length)];
        p.ch = ch == null ? "" : ch;
        if (ps.size() > 36) ps.remove(0);
        ps.add(p);
        invalidate();
    }

    /** Thả một con bướm phát sáng bay ra từ (x, y). */
    public void spawnButterfly(float x, float y) {
        B b = new B();
        b.x0 = x;
        b.y0 = y;
        double ang = Math.toRadians(-90 + (rnd.nextFloat() - 0.5f) * 220);
        float sp = (45 + rnd.nextInt(60)) * dp;
        b.vx = (float) Math.cos(ang) * sp;
        b.vy = (float) Math.sin(ang) * sp;
        b.size = (13 + rnd.nextInt(8)) * dp;
        b.phase = rnd.nextFloat() * 6.28f;
        b.flapHz = 9f + rnd.nextFloat() * 4f;
        b.born = SystemClock.uptimeMillis();
        b.life = 1500 + rnd.nextInt(700);
        b.color = BF_COLORS[rnd.nextInt(BF_COLORS.length)];
        if (bs.size() > 14) bs.remove(0);
        bs.add(b);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();

        Iterator<P> it = ps.iterator();
        while (it.hasNext()) {
            P p = it.next();
            float t = (now - p.born) / (float) LIFE;
            if (t >= 1f) {
                it.remove();
                continue;
            }
            float ease = 1f - (1f - t) * (1f - t);
            float y = p.y0 - 150f * dp * ease;
            float x = p.x0 + (float) Math.sin(p.phase + t * 5f) * 14f * dp;
            float scale = 0.55f + 0.45f * Math.min(1f, t * 5f);
            int alpha = (int) (255 * (1f - t * t));
            float s = p.size * scale;

            m.reset();
            m.postScale(s, s);
            m.postTranslate(x, y);
            tmp.reset();
            unitHeart.transform(m, tmp);
            fill.setColor((p.color & 0x00FFFFFF) | (alpha << 24));
            c.drawPath(tmp, fill);

            if (!p.ch.isEmpty()) {
                letter.setTextSize(s * 0.46f);
                letter.setAlpha(alpha);
                c.drawText(p.ch, x, y - s * 0.03f + s * 0.46f * 0.35f, letter);
            }
        }

        Iterator<B> bit = bs.iterator();
        while (bit.hasNext()) {
            B b = bit.next();
            float age = now - b.born;
            float t = age / b.life;
            if (t >= 1f) {
                bit.remove();
                continue;
            }
            float sec = age / 1000f;
            float x = b.x0 + b.vx * sec + (float) Math.sin(b.phase + sec * 4f) * 10f * dp;
            float y = b.y0 + b.vy * sec + (float) Math.cos(b.phase + sec * 3f) * 6f * dp;
            float dx = b.vx + (float) Math.cos(b.phase + sec * 4f) * 40f * dp;
            float dy = b.vy - (float) Math.sin(b.phase + sec * 3f) * 18f * dp;
            float heading = (float) Math.toDegrees(Math.atan2(dy, dx)) + 90f;
            int alpha;
            if (t < 0.15f) alpha = (int) (255 * t / 0.15f);
            else if (t > 0.6f) alpha = (int) (255 * (1f - t) / 0.4f);
            else alpha = 255;
            float flap = 0.25f + 0.75f * Math.abs((float) Math.cos(sec * b.flapHz * Math.PI));
            drawButterfly(c, x, y, b.size, heading, flap, b.color, alpha);
        }

        if (!ps.isEmpty() || !bs.isEmpty()) postInvalidateOnAnimation();
    }

    private void drawButterfly(Canvas c, float x, float y, float size, float heading,
                               float flap, int color, int alpha) {
        int rgb = color & 0x00FFFFFF;

        // vầng sáng quanh con bướm
        glow.setShader(new RadialGradient(x, y, size * 2.2f,
                new int[]{((alpha * 0x80 / 255) << 24) | rgb, rgb},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, size * 2.2f, glow);
        glow.setShader(null);

        c.save();
        c.translate(x, y);
        c.rotate(heading);
        c.scale(size, size);

        wing.setColor(((alpha * 0xD8 / 255) << 24) | rgb);
        wingLine.setColor(((alpha * 0xB0 / 255) << 24) | 0x00FFFFFF);
        c.save();
        c.scale(flap, 1f);
        c.drawPath(wingUpper, wing);
        c.drawPath(wingLower, wing);
        c.drawPath(wingUpper, wingLine);
        c.drawPath(wingLower, wingLine);
        c.scale(-1f, 1f);
        c.drawPath(wingUpper, wing);
        c.drawPath(wingLower, wing);
        c.drawPath(wingUpper, wingLine);
        c.drawPath(wingLower, wingLine);
        c.restore();

        body.setColor(((alpha * 0xF0 / 255) << 24) | 0x00FFFFFF);
        c.drawLine(0f, -0.45f, 0f, 0.6f, body);
        c.restore();
    }
}
