package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

import java.util.Random;

/** Drawable vẽ sẵn vào bitmap một lần (khi biết kích thước) rồi chỉ việc dán lại: nhẹ khi cuộn/nhấn. */
abstract class CachedDrawable extends Drawable {
    private Bitmap bmp;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

    abstract void render(Canvas c, int w, int h);

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) {
            bmp = null;
            return;
        }
        if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            render(new Canvas(bmp), w, h);
        }
    }

    @Override
    public void draw(Canvas c) {
        if (bmp != null) {
            Rect b = getBounds();
            c.drawBitmap(bmp, b.left, b.top, paint);
        }
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter filter) {
        paint.setColorFilter(filter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    static int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }
}

/** Phím phủ lông: viên thuốc màu kem, đầy sợi lông ngắn và viền lông xù. */
final class FurDrawable extends CachedDrawable {
    private final int base;
    private final boolean pressed;
    private final float dp;
    private final long seed;

    FurDrawable(int base, boolean pressed, float dp, long seed) {
        this.base = base;
        this.pressed = pressed;
        this.dp = dp;
        this.seed = seed;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static boolean inside(float x, float y, RectF r, float rad) {
        float ax;
        float bx;
        float ay;
        float by;
        if (r.width() >= r.height()) {
            ax = r.left + rad;
            bx = r.right - rad;
            ay = r.centerY();
            by = ay;
        } else {
            ax = r.centerX();
            bx = ax;
            ay = r.top + rad;
            by = r.bottom - rad;
        }
        float px = clamp(x, Math.min(ax, bx), Math.max(ax, bx));
        float py = clamp(y, Math.min(ay, by), Math.max(ay, by));
        float dx = x - px;
        float dy = y - py;
        return dx * dx + dy * dy <= rad * rad;
    }

    @Override
    void render(Canvas c, int w, int h) {
        float m = 5f * dp;
        RectF r = new RectF(m, m, w - m, h - m);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        float cx = r.centerX();
        float cy = r.centerY();
        int body = pressed ? mix(base, Color.BLACK, 0.12f) : base;
        Random rnd = new Random(seed);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ mềm
        p.setColor(0x40000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2.5f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.8f * dp, r.right, r.bottom + 1.8f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân phím: sáng ở trên, tối nhẹ ở dưới
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{mix(body, Color.WHITE, 0.35f), body, mix(body, Color.BLACK, 0.14f)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // sợi lông bên trong
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeCap(Paint.Cap.ROUND);
        s.setStrokeWidth(Math.max(1f, 0.9f * dp));
        int light = mix(body, Color.WHITE, 0.65f);
        int dark = mix(body, 0xFF8B7355, 0.55f);
        int n = Math.min(1200, (int) (r.width() * r.height() / (5f * dp * dp)));
        for (int i = 0; i < n; i++) {
            float x = r.left + rnd.nextFloat() * r.width();
            float y = r.top + rnd.nextFloat() * r.height();
            if (!inside(x, y, r, rad)) continue;
            double ang = Math.toRadians(90 + (rnd.nextFloat() - 0.5f) * 110);
            float len = (3f + rnd.nextFloat() * 4f) * dp;
            boolean isLight = rnd.nextFloat() < 0.55f;
            int col = isLight ? light : dark;
            int a = isLight ? 120 + rnd.nextInt(90) : 60 + rnd.nextInt(50);
            s.setColor((col & 0x00FFFFFF) | (a << 24));
            c.drawLine(x, y, x + (float) Math.cos(ang) * len, y + (float) Math.sin(ang) * len, s);
        }

        // viền lông xù: sợi mọc ra ngoài theo đường viền
        Path path = new Path();
        path.addRoundRect(r, rad, rad, Path.Direction.CW);
        PathMeasure pm = new PathMeasure(path, true);
        float total = pm.getLength();
        float[] pos = new float[2];
        float[] tan = new float[2];
        float step = Math.max(1f, 1.6f * dp);
        int fuzz = mix(body, Color.WHITE, 0.5f);
        for (float d = 0; d < total; d += step) {
            pm.getPosTan(d, pos, tan);
            float nx = -tan[1];
            float ny = tan[0];
            if (nx * (pos[0] - cx) + ny * (pos[1] - cy) < 0) {
                nx = -nx;
                ny = -ny;
            }
            float ang = (rnd.nextFloat() - 0.5f) * 1.1f;
            float cs = (float) Math.cos(ang);
            float sn = (float) Math.sin(ang);
            float dx = nx * cs - ny * sn;
            float dy = nx * sn + ny * cs;
            float len = (1.5f + rnd.nextFloat() * 3.2f) * dp;
            int a = 150 + rnd.nextInt(80);
            s.setColor((fuzz & 0x00FFFFFF) | (a << 24));
            c.drawLine(pos[0] - nx * dp, pos[1] - ny * dp, pos[0] + dx * len, pos[1] + dy * len, s);
        }
    }
}

/** Nút kính bóng: thân tô màu, viền sáng, vệt sáng phía trên. */
final class BubbleDrawable extends CachedDrawable {
    private final int tint;
    private final boolean pressed;
    private final float dp;

    BubbleDrawable(int tint, boolean pressed, float dp) {
        this.tint = tint;
        this.pressed = pressed;
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        float m = 3f * dp;
        RectF r = new RectF(m, m, w - m, h - m);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ
        p.setColor(0x55000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2.2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.5f * dp, r.right, r.bottom + 1.5f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân kính
        int body = pressed ? mix(tint, Color.BLACK, 0.3f) : tint;
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{mix(body, Color.WHITE, 0.25f), body, mix(body, Color.BLACK, 0.3f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền sáng
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.6f * dp));
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF0FFFFFF, 0x55FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền trong mờ
        float in = 3f * dp;
        RectF ri = new RectF(r.left + in, r.top + in, r.right - in, r.bottom - in);
        if (ri.width() > 2 && ri.height() > 2) {
            p.setStrokeWidth(Math.max(1f, dp));
            p.setColor(0x33FFFFFF);
            float rr = Math.max(0f, rad - in);
            c.drawRoundRect(ri, rr, rr, p);
        }

        // vệt sáng phía trên
        p.setStyle(Paint.Style.FILL);
        RectF hi = new RectF(r.left + r.width() * 0.12f, r.top + 2f * dp,
                r.right - r.width() * 0.12f, r.top + r.height() * 0.46f);
        if (hi.width() > 2 && hi.height() > 2) {
            p.setShader(new LinearGradient(0, hi.top, 0, hi.bottom, pressed ? 0x66FFFFFF : 0xAAFFFFFF,
                    0x05FFFFFF, Shader.TileMode.CLAMP));
            float hr = Math.min(hi.width(), hi.height()) / 2f;
            c.drawRoundRect(hi, hr, hr, p);
            p.setShader(null);
        }
    }
}
