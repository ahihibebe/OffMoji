package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Drawable vẽ sẵn vào bitmap một lần (khi biết kích thước) rồi chỉ việc dán lại: nhẹ khi cuộn/nhấn. */
abstract class CachedDrawable extends Drawable {
    private Bitmap bmp;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

    abstract void render(Canvas c, int w, int h);

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) {
            bmp = null;
            return;
        }
        if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            render(new Canvas(bmp), w, h);
        }
    }

    @Override
    public void draw(Canvas c) {
        if (bmp != null) {
            Rect b = getBounds();
            c.drawBitmap(bmp, b.left, b.top, paint);
        }
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter filter) {
        paint.setColorFilter(filter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    static int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    /** Phím gần vuông -> hình tròn; phím dài (dấu cách) -> viên thuốc. */
    static RectF shapeRect(int w, int h, float margin) {
        float aw = w - 2 * margin;
        float ah = h - 2 * margin;
        if (aw <= 0 || ah <= 0) return new RectF(0, 0, 0, 0);
        if (aw / ah < 1.6f) {
            float s = Math.min(aw, ah);
            float cx = w / 2f;
            float cy = h / 2f;
            return new RectF(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
        }
        return new RectF(margin, margin, w - margin, h - margin);
    }
}

/** Nút kính bóng tròn (giao diện Bông): thân tô màu, viền sáng, vệt sáng phía trên. */
final class BubbleDrawable extends CachedDrawable {
    private final int tint;
    private final boolean pressed;
    private final float dp;

    BubbleDrawable(int tint, boolean pressed, float dp) {
        this.tint = tint;
        this.pressed = pressed;
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        RectF r = shapeRect(w, h, 2.5f * dp);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ
        p.setColor(0x55000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2.2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.5f * dp, r.right, r.bottom + 1.5f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân kính
        int body = pressed ? mix(tint, Color.BLACK, 0.3f) : tint;
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{mix(body, Color.WHITE, 0.25f), body, mix(body, Color.BLACK, 0.3f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền sáng
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.6f * dp));
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF0FFFFFF, 0x55FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền trong mờ
        float in = 3f * dp;
        RectF ri = new RectF(r.left + in, r.top + in, r.right - in, r.bottom - in);
        if (ri.width() > 2 && ri.height() > 2) {
            p.setStrokeWidth(Math.max(1f, dp));
            p.setColor(0x33FFFFFF);
            float rr = Math.max(0f, rad - in);
            c.drawRoundRect(ri, rr, rr, p);
        }

        // vệt sáng phía trên
        p.setStyle(Paint.Style.FILL);
        RectF hi = new RectF(r.left + r.width() * 0.14f, r.top + 2f * dp,
                r.right - r.width() * 0.14f, r.top + r.height() * 0.46f);
        if (hi.width() > 2 && hi.height() > 2) {
            p.setShader(new LinearGradient(0, hi.top, 0, hi.bottom, pressed ? 0x66FFFFFF : 0xAAFFFFFF,
                    0x05FFFFFF, Shader.TileMode.CLAMP));
            float hr = Math.min(hi.width(), hi.height()) / 2f;
            c.drawRoundRect(hi, hr, hr, p);
            p.setShader(null);
        }
    }
}

/** Phím kính 3D: thân kính đỏ thẫm, bóng trong ở đáy, viền sáng và vệt phản chiếu phía trên. */
final class GlassKeyDrawable extends CachedDrawable {
    private final boolean special;
    private final boolean pressed;
    private final float dp;

    GlassKeyDrawable(boolean special, boolean pressed, float dp) {
        this.special = special;
        this.pressed = pressed;
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        float m = 2f * dp;
        RectF r = new RectF(m, m, w - m, h - m);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        if (aspect(r) >= 1.6f) rad = Math.min(14f * dp, rad);
        int tint = special ? 0xFFC62832 : 0xFF6A1822;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ xuống nền
        p.setColor(0x44000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.5f * dp, r.right, r.bottom + 1.5f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân kính: sáng nhẹ ở trên, đậm ở đáy
        int aTop = pressed ? 0xC0 : 0x9A;
        int aMid = pressed ? 0xB0 : 0x88;
        int aBot = pressed ? 0xD8 : 0xB8;
        int top = (aTop << 24) | (mix(tint, Color.WHITE, 0.22f) & 0x00FFFFFF);
        int mid = (aMid << 24) | (tint & 0x00FFFFFF);
        int bot = (aBot << 24) | (mix(tint, Color.BLACK, 0.35f) & 0x00FFFFFF);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, new int[]{top, mid, bot},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // bóng trong ở đáy: tạo cảm giác có độ dày
        c.save();
        Path clip = new Path();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.clipPath(clip);
        p.setShader(new LinearGradient(0, r.top + r.height() * 0.55f, 0, r.bottom,
                0x00200008, 0x55200008, Shader.TileMode.CLAMP));
        c.drawRect(r, p);
        p.setShader(null);
        c.restore();

        // viền ngoài trắng sáng ở trên, hồng nhạt ở dưới
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.3f * dp));
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF8FFFFFF, 0x80FFC9CD, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // vệt phản chiếu phía trên
        p.setStyle(Paint.Style.FILL);
        RectF hi = new RectF(r.left + r.width() * 0.14f, r.top + 1.5f * dp,
                r.right - r.width() * 0.14f, r.top + r.height() * 0.44f);
        if (hi.width() > 2 && hi.height() > 2) {
            float hr = Math.min(hi.width(), hi.height()) / 2f;
            p.setShader(new LinearGradient(0, hi.top, 0, hi.bottom, pressed ? 0x55FFFFFF : 0xAAFFFFFF,
                    0x04FFFFFF, Shader.TileMode.CLAMP));
            c.drawRoundRect(hi, hr, hr, p);
            p.setShader(null);
        }
    }

    private static float aspect(RectF r) {
        return r.width() / r.height();
    }
}

/** Nền bàn phím kính lỏng 3D: tấm kính mờ xám chuyển đỏ, cạnh vát sáng, dải phản chiếu chéo, bóng trong. */
final class GlassPanelDrawable extends CachedDrawable {
    private final float dp;

    GlassPanelDrawable(float dp) {
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // tấm kính: trắng mờ ở trên, xanh nhạt ở dưới
        p.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x55E6E6EA, 0x3AA7A7AF, 0x88C23A44},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // dải phản chiếu chéo
        Path band = new Path();
        band.moveTo(w * 0.05f, 0);
        band.lineTo(w * 0.42f, 0);
        band.lineTo(w * 0.18f, h);
        band.lineTo(-w * 0.19f, h);
        band.close();
        p.setShader(new LinearGradient(0, 0, w * 0.42f, 0, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawPath(band, p);
        p.setShader(null);

        Path band2 = new Path();
        band2.moveTo(w * 0.62f, 0);
        band2.lineTo(w * 0.74f, 0);
        band2.lineTo(w * 0.52f, h);
        band2.lineTo(w * 0.40f, h);
        band2.close();
        p.setColor(0x20FFFFFF);
        c.drawPath(band2, p);

        // cạnh vát sáng phía trên
        float glow = 6f * dp;
        p.setShader(new LinearGradient(0, 0, 0, glow, 0xCCFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, glow, p);
        p.setShader(null);
        p.setColor(0xE6FFFFFF);
        c.drawRect(0, 0, w, Math.max(1f, 1.5f * dp), p);

        // bóng trong ở đáy
        float shade = 14f * dp;
        p.setShader(new LinearGradient(0, h - shade, 0, h, 0x00300008, 0x44300008, Shader.TileMode.CLAMP));
        c.drawRect(0, h - shade, w, h, p);
        p.setShader(null);

        // ánh sáng hai bên cạnh
        float side = 8f * dp;
        p.setShader(new LinearGradient(0, 0, side, 0, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, side, h, p);
        p.setShader(new LinearGradient(w - side, 0, w, 0, 0x00FFFFFF, 0x40FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(w - side, 0, w, h, p);
        p.setShader(null);
    }
}
