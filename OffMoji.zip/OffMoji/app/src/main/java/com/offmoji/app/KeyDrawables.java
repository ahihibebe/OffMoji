package com.offmoji.app;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

import java.util.Random;

/** Drawable vẽ sẵn vào bitmap một lần (khi biết kích thước) rồi chỉ việc dán lại: nhẹ khi cuộn/nhấn. */
abstract class CachedDrawable extends Drawable {
    private Bitmap bmp;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

    abstract void render(Canvas c, int w, int h);

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) {
            bmp = null;
            return;
        }
        if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            render(new Canvas(bmp), w, h);
        }
    }

    @Override
    public void draw(Canvas c) {
        if (bmp != null) {
            Rect b = getBounds();
            c.drawBitmap(bmp, b.left, b.top, paint);
        }
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter filter) {
        paint.setColorFilter(filter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    static int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    /** Phím gần vuông -> hình tròn; phím dài (dấu cách) -> viên thuốc. */
    static RectF shapeRect(int w, int h, float margin) {
        float aw = w - 2 * margin;
        float ah = h - 2 * margin;
        if (aw <= 0 || ah <= 0) return new RectF(0, 0, 0, 0);
        if (aw / ah < 1.6f) {
            float s = Math.min(aw, ah);
            float cx = w / 2f;
            float cy = h / 2f;
            return new RectF(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
        }
        return new RectF(margin, margin, w - margin, h - margin);
    }
}

/** Phím phủ lông: tròn/viên thuốc màu kem, đầy sợi lông ngắn và viền lông xù. */
final class FurDrawable extends CachedDrawable {
    private final int base;
    private final boolean pressed;
    private final float dp;
    private final long seed;

    FurDrawable(int base, boolean pressed, float dp, long seed) {
        this.base = base;
        this.pressed = pressed;
        this.dp = dp;
        this.seed = seed;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static boolean inside(float x, float y, RectF r, float rad) {
        float ax;
        float bx;
        float ay;
        float by;
        if (r.width() >= r.height()) {
            ax = r.left + rad;
            bx = r.right - rad;
            ay = r.centerY();
            by = ay;
        } else {
            ax = r.centerX();
            bx = ax;
            ay = r.top + rad;
            by = r.bottom - rad;
        }
        float px = clamp(x, Math.min(ax, bx), Math.max(ax, bx));
        float py = clamp(y, Math.min(ay, by), Math.max(ay, by));
        float dx = x - px;
        float dy = y - py;
        return dx * dx + dy * dy <= rad * rad;
    }

    @Override
    void render(Canvas c, int w, int h) {
        RectF r = shapeRect(w, h, 3.5f * dp);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        float cx = r.centerX();
        float cy = r.centerY();
        int body = pressed ? mix(base, Color.BLACK, 0.12f) : base;
        Random rnd = new Random(seed);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ mềm
        p.setColor(0x40000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2.2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.6f * dp, r.right, r.bottom + 1.6f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân phím: sáng ở trên, tối nhẹ ở dưới
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{mix(body, Color.WHITE, 0.35f), body, mix(body, Color.BLACK, 0.14f)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // sợi lông bên trong
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeCap(Paint.Cap.ROUND);
        s.setStrokeWidth(Math.max(1f, 0.9f * dp));
        int light = mix(body, Color.WHITE, 0.65f);
        int dark = mix(body, 0xFF8B7355, 0.55f);
        int n = Math.min(900, (int) (r.width() * r.height() / (5f * dp * dp)));
        for (int i = 0; i < n; i++) {
            float x = r.left + rnd.nextFloat() * r.width();
            float y = r.top + rnd.nextFloat() * r.height();
            if (!inside(x, y, r, rad)) continue;
            double ang = Math.toRadians(90 + (rnd.nextFloat() - 0.5f) * 110);
            float len = (3f + rnd.nextFloat() * 4f) * dp;
            boolean isLight = rnd.nextFloat() < 0.55f;
            int col = isLight ? light : dark;
            int a = isLight ? 120 + rnd.nextInt(90) : 60 + rnd.nextInt(50);
            s.setColor((col & 0x00FFFFFF) | (a << 24));
            c.drawLine(x, y, x + (float) Math.cos(ang) * len, y + (float) Math.sin(ang) * len, s);
        }

        // viền lông xù: sợi mọc ra ngoài theo đường viền
        Path path = new Path();
        path.addRoundRect(r, rad, rad, Path.Direction.CW);
        PathMeasure pm = new PathMeasure(path, true);
        float total = pm.getLength();
        float[] pos = new float[2];
        float[] tan = new float[2];
        float step = Math.max(1f, 1.4f * dp);
        int fuzz = mix(body, Color.WHITE, 0.5f);
        for (float d = 0; d < total; d += step) {
            pm.getPosTan(d, pos, tan);
            float nx = -tan[1];
            float ny = tan[0];
            if (nx * (pos[0] - cx) + ny * (pos[1] - cy) < 0) {
                nx = -nx;
                ny = -ny;
            }
            float ang = (rnd.nextFloat() - 0.5f) * 1.1f;
            float cs = (float) Math.cos(ang);
            float sn = (float) Math.sin(ang);
            float dx = nx * cs - ny * sn;
            float dy = nx * sn + ny * cs;
            float len = (1.2f + rnd.nextFloat() * 2.0f) * dp;
            int a = 150 + rnd.nextInt(80);
            s.setColor((fuzz & 0x00FFFFFF) | (a << 24));
            c.drawLine(pos[0] - nx * dp, pos[1] - ny * dp, pos[0] + dx * len, pos[1] + dy * len, s);
        }
    }
}

/** Nút kính bóng tròn: thân tô màu, viền sáng, vệt sáng phía trên. */
final class BubbleDrawable extends CachedDrawable {
    private final int tint;
    private final boolean pressed;
    private final float dp;

    BubbleDrawable(int tint, boolean pressed, float dp) {
        this.tint = tint;
        this.pressed = pressed;
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        RectF r = shapeRect(w, h, 2.5f * dp);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(r.width(), r.height()) / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ
        p.setColor(0x55000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2.2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.5f * dp, r.right, r.bottom + 1.5f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân kính
        int body = pressed ? mix(tint, Color.BLACK, 0.3f) : tint;
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{mix(body, Color.WHITE, 0.25f), body, mix(body, Color.BLACK, 0.3f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền sáng
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.6f * dp));
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF0FFFFFF, 0x55FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // viền trong mờ
        float in = 3f * dp;
        RectF ri = new RectF(r.left + in, r.top + in, r.right - in, r.bottom - in);
        if (ri.width() > 2 && ri.height() > 2) {
            p.setStrokeWidth(Math.max(1f, dp));
            p.setColor(0x33FFFFFF);
            float rr = Math.max(0f, rad - in);
            c.drawRoundRect(ri, rr, rr, p);
        }

        // vệt sáng phía trên
        p.setStyle(Paint.Style.FILL);
        RectF hi = new RectF(r.left + r.width() * 0.14f, r.top + 2f * dp,
                r.right - r.width() * 0.14f, r.top + r.height() * 0.46f);
        if (hi.width() > 2 && hi.height() > 2) {
            p.setShader(new LinearGradient(0, hi.top, 0, hi.bottom, pressed ? 0x66FFFFFF : 0xAAFFFFFF,
                    0x05FFFFFF, Shader.TileMode.CLAMP));
            float hr = Math.min(hi.width(), hi.height()) / 2f;
            c.drawRoundRect(hi, hr, hr, p);
            p.setShader(null);
        }
    }
}

/** Phím kính 3D: thân trong mờ, bóng trong ở đáy, viền sáng vát và vệt phản chiếu phía trên. */
final class GlassKeyDrawable extends CachedDrawable {
    private final boolean special;
    private final boolean pressed;
    private final float dp;

    GlassKeyDrawable(boolean special, boolean pressed, float dp) {
        this.special = special;
        this.pressed = pressed;
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        float m = 2f * dp;
        RectF r = new RectF(m, m, w - m, h - m);
        if (r.width() <= 4 || r.height() <= 4) return;
        float rad = Math.min(10f * dp, Math.min(r.width(), r.height()) / 2f);
        int tint = special ? 0xBFD9FF : 0xFFFFFF;
        int tintLow = special ? 0xA8D0FF : 0xE6F0FF;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // bóng đổ xuống nền
        p.setColor(0x38000000);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, 2f * dp), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(new RectF(r.left, r.top + 1.5f * dp, r.right, r.bottom + 1.5f * dp), rad, rad, p);
        p.setMaskFilter(null);

        // thân kính (đậm ở trên, trong ở giữa, hơi xanh ở đáy)
        int aTop = pressed ? 0xC8 : 0xA0;
        int aMid = pressed ? 0x90 : 0x62;
        int aBot = pressed ? 0x78 : 0x48;
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{(aTop << 24) | tint, (aMid << 24) | tint, (aBot << 24) | tintLow},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // bóng trong ở đáy: tạo cảm giác có độ dày
        c.save();
        Path clip = new Path();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.clipPath(clip);
        p.setShader(new LinearGradient(0, r.top + r.height() * 0.55f, 0, r.bottom,
                0x00102A56, 0x4D102A56, Shader.TileMode.CLAMP));
        c.drawRect(r, p);
        p.setShader(null);
        c.restore();

        // viền ngoài sáng ở trên, mờ dần xuống dưới
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.2f * dp));
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF2FFFFFF, 0x70CFE6FF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // vệt phản chiếu phía trên
        p.setStyle(Paint.Style.FILL);
        RectF hi = new RectF(r.left + r.width() * 0.08f, r.top + 1.5f * dp,
                r.right - r.width() * 0.08f, r.top + r.height() * 0.42f);
        if (hi.width() > 2 && hi.height() > 2) {
            float hr = Math.min(rad, hi.height() / 2f);
            p.setShader(new LinearGradient(0, hi.top, 0, hi.bottom, pressed ? 0x66FFFFFF : 0xB0FFFFFF,
                    0x04FFFFFF, Shader.TileMode.CLAMP));
            c.drawRoundRect(hi, hr, hr, p);
            p.setShader(null);
        }
    }
}

/** Nền bàn phím kính lỏng 3D: tấm kính mờ có cạnh vát sáng, dải phản chiếu chéo và bóng trong. */
final class GlassPanelDrawable extends CachedDrawable {
    private final float dp;

    GlassPanelDrawable(float dp) {
        this.dp = dp;
    }

    @Override
    void render(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // tấm kính: trắng mờ ở trên, xanh nhạt ở dưới
        p.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x66FFFFFF, 0x2EE8F4FF, 0x4AA8D4FF},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // dải phản chiếu chéo
        Path band = new Path();
        band.moveTo(w * 0.05f, 0);
        band.lineTo(w * 0.42f, 0);
        band.lineTo(w * 0.18f, h);
        band.lineTo(-w * 0.19f, h);
        band.close();
        p.setShader(new LinearGradient(0, 0, w * 0.42f, 0, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawPath(band, p);
        p.setShader(null);

        Path band2 = new Path();
        band2.moveTo(w * 0.62f, 0);
        band2.lineTo(w * 0.74f, 0);
        band2.lineTo(w * 0.52f, h);
        band2.lineTo(w * 0.40f, h);
        band2.close();
        p.setColor(0x20FFFFFF);
        c.drawPath(band2, p);

        // cạnh vát sáng phía trên
        float glow = 6f * dp;
        p.setShader(new LinearGradient(0, 0, 0, glow, 0xCCFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, glow, p);
        p.setShader(null);
        p.setColor(0xE6FFFFFF);
        c.drawRect(0, 0, w, Math.max(1f, 1.5f * dp), p);

        // bóng trong ở đáy
        float shade = 14f * dp;
        p.setShader(new LinearGradient(0, h - shade, 0, h, 0x00001F4D, 0x330A2A5C, Shader.TileMode.CLAMP));
        c.drawRect(0, h - shade, w, h, p);
        p.setShader(null);

        // ánh sáng hai bên cạnh
        float side = 8f * dp;
        p.setShader(new LinearGradient(0, 0, side, 0, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, side, h, p);
        p.setShader(new LinearGradient(w - side, 0, w, 0, 0x00FFFFFF, 0x40FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(w - side, 0, w, h, p);
        p.setShader(null);
    }
}
