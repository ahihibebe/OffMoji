package com.offmoji.app;

import android.content.Context;

import java.io.File;
import java.util.Arrays;

/** Nơi lưu sticker cá nhân (bộ nhớ riêng của app, không cần quyền gì). */
final class StickerStore {
    private StickerStore() {}

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "stickers");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File[] list(Context c) {
        File[] fs = dir(c).listFiles((d, name) -> name.startsWith("stk_") && name.endsWith(".png"));
        if (fs == null) return new File[0];
        Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return fs;
    }
}
