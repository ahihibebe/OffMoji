package com.offmoji.app;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

/** Nơi lưu sticker cá nhân + sticker hài hước dựng sẵn (bộ nhớ riêng của app, không cần quyền gì). */
final class StickerStore {
    private StickerStore() {}

    /** Kích thước cố định (px) của sticker hài hước = đúng cỡ ảnh xem trước. Đổi ở đúng 1 chỗ này. */
    static final int FUNNY_SIZE = 128;

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "stickers");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File[] list(Context c) {
        File[] fs = dir(c).listFiles((d, name) -> name.startsWith("stk_") && name.endsWith(".png"));
        if (fs == null) return new File[0];
        Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return fs;
    }

    private static File builtinDir(Context c) {
        File d = new File(dir(c), "builtin");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** File PNG của sticker hài hước thứ idx ở kích thước đang chọn (tự tạo nếu chưa có). */
    static File funnyFile(Context c, int idx) throws IOException {
        int size = FUNNY_SIZE;
        File d = builtinDir(c);
        String prefix = "fun_v3_" + size + "_";
        File f = new File(d, prefix + idx + ".png");
        if (!f.exists()) {
            // dọn file của kích thước cũ cho đỡ tốn dung lượng
            File[] old = d.listFiles();
            if (old != null) {
                for (File o : old) {
                    if (!o.getName().startsWith(prefix)) o.delete();
                }
            }
            Bitmap b = StickerArt.renderFunny(idx, size);
            FileOutputStream out = new FileOutputStream(f);
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            b.recycle();
        }
        return f;
    }
}
