package com.offmoji.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Các kiểu chữ Unicode (in đậm, nghiêng, viết tay, bong bóng...). Hoạt động hoàn toàn offline. */
public final class FontStyles {
    private FontStyles() {}

    public static final class Style {
        public final String name;
        final int upper;      // mã Unicode của 'A' trong kiểu này (-1 nếu không đổi)
        final int lower;      // mã Unicode của 'a'
        final int digit;      // mã Unicode của '0' (-1 nếu không đổi)
        final Map<Integer, Integer> exceptions = new HashMap<>();
        final String smallCaps;   // 26 ký tự thay thế a-z (nếu có)
        final int combining;      // dấu kết hợp gắn sau mỗi ký tự (0 nếu không)

        Style(String name, int upper, int lower, int digit, int[][] ex, String smallCaps, int combining) {
            this.name = name;
            this.upper = upper;
            this.lower = lower;
            this.digit = digit;
            this.smallCaps = smallCaps;
            this.combining = combining;
            if (ex != null) for (int[] p : ex) exceptions.put(p[0], p[1]);
        }
    }

    public static final List<Style> ALL = new ArrayList<>();

    private static void add(String name, int up, int low, int dig, int[][] ex) {
        ALL.add(new Style(name, up, low, dig, ex, null, 0));
    }

    static {
        add("In đậm", 0x1D400, 0x1D41A, 0x1D7CE, null);
        add("In nghiêng", 0x1D434, 0x1D44E, -1, new int[][]{{'h', 0x210E}});
        add("Đậm nghiêng", 0x1D468, 0x1D482, 0x1D7CE, null);
        add("Viết tay", 0x1D49C, 0x1D4B6, -1, new int[][]{
            {'B', 0x212C}, {'E', 0x2130}, {'F', 0x2131}, {'H', 0x210B}, {'I', 0x2110},
            {'L', 0x2112}, {'M', 0x2133}, {'R', 0x211B}, {'e', 0x212F}, {'g', 0x210A}, {'o', 0x2134}});
        add("Viết tay đậm", 0x1D4D0, 0x1D4EA, 0x1D7CE, null);
        add("Gothic", 0x1D504, 0x1D51E, -1, new int[][]{
            {'C', 0x212D}, {'H', 0x210C}, {'I', 0x2111}, {'R', 0x211C}, {'Z', 0x2128}});
        add("Gothic đậm", 0x1D56C, 0x1D586, 0x1D7CE, null);
        add("Nét đôi", 0x1D538, 0x1D552, 0x1D7D8, new int[][]{
            {'C', 0x2102}, {'H', 0x210D}, {'N', 0x2115}, {'P', 0x2119}, {'Q', 0x211A},
            {'R', 0x211D}, {'Z', 0x2124}});
        add("Sans", 0x1D5A0, 0x1D5BA, 0x1D7E2, null);
        add("Sans đậm", 0x1D5D4, 0x1D5EE, 0x1D7EC, null);
        add("Sans nghiêng", 0x1D608, 0x1D622, -1, null);
        add("Sans đậm nghiêng", 0x1D63C, 0x1D656, 0x1D7EC, null);
        add("Đánh máy", 0x1D670, 0x1D68A, 0x1D7F6, null);
        add("Bong bóng", 0x24B6, 0x24D0, -1, new int[][]{
            {'0', 0x24EA}, {'1', 0x2460}, {'2', 0x2461}, {'3', 0x2462}, {'4', 0x2463},
            {'5', 0x2464}, {'6', 0x2465}, {'7', 0x2466}, {'8', 0x2467}, {'9', 0x2468}});
        add("Bong bóng đen", 0x1F150, 0x1F150, -1, null);
        add("Ô vuông", 0x1F130, 0x1F130, -1, null);
        add("Ô vuông đen", 0x1F170, 0x1F170, -1, null);
        add("Toàn chiều rộng", 0xFF21, 0xFF41, 0xFF10, null);
        ALL.add(new Style("Chữ hoa nhỏ", -1, -1, -1, null, "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ", 0));
        ALL.add(new Style("Gạch ngang", -1, -1, -1, null, null, 0x0336));
        ALL.add(new Style("Gạch chân", -1, -1, -1, null, null, 0x0332));
    }

    public static String apply(Style s, String text) {
        if (s == null) return text;
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            sb.appendCodePoint(mapOne(s, cp));
            if (s.combining != 0 && cp != ' ' && cp != '\n') sb.appendCodePoint(s.combining);
        }
        return sb.toString();
    }

    private static int mapOne(Style s, int cp) {
        Integer ex = s.exceptions.get(cp);
        if (ex != null) return ex;
        if (s.smallCaps != null) {
            if (cp >= 'a' && cp <= 'z') return s.smallCaps.charAt(cp - 'a');
            if (cp >= 'A' && cp <= 'Z') return s.smallCaps.charAt(cp - 'A');
            return cp;
        }
        if (cp >= 'A' && cp <= 'Z' && s.upper >= 0) return s.upper + (cp - 'A');
        if (cp >= 'a' && cp <= 'z' && s.lower >= 0) return s.lower + (cp - 'a');
        if (cp >= '0' && cp <= '9' && s.digit >= 0) return s.digit + (cp - '0');
        return cp;
    }
}
