package com.offmoji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 1;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int ACCENT = 0xFF1A73E8;

    private SharedPreferences prefs;
    private float dp = 1f;

    private TextView status;
    private ImageView preview;
    private EditText caption;
    private TextView btnPos;
    private TextView btnRound;
    private GridLayout myStickers;
    private LinearLayout styleList;
    private EditText styleInput;
    private final TextView[] themeChips = new TextView[Themes.NAMES.length];

    private Bitmap srcBitmap;
    private boolean captionTop = false;
    private boolean rounded = true;

    private int px(float d) {
        return Math.round(d * dp);
    }

    // ------------------------------------------------------------------ dựng giao diện

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF1F3F6);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(px(14), px(18), px(14), px(30));
        sv.addView(page, new ViewGroup.LayoutParams(MATCH, WRAP));

        TextView title = text("OffMoji", 28, true);
        page.addView(title);
        TextView sub = text("Bàn phím emoji, kiểu chữ và sticker cá nhân — chạy hoàn toàn offline, "
                + "app không xin quyền Internet.", 14, false);
        sub.setTextColor(0xFF555B66);
        page.addView(sub, lpTop(4));

        // --- 1. cài đặt bàn phím
        LinearLayout c1 = card(page, "1. Bật bàn phím");
        status = text("", 14, false);
        c1.addView(status);
        TextView b1 = button("Bước 1: Bật OffMoji trong cài đặt");
        b1.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        c1.addView(b1, lpTop(8));
        TextView b2 = button("Bước 2: Chọn OffMoji làm bàn phím");
        b2.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        c1.addView(b2, lpTop(8));
        EditText test = new EditText(this);
        test.setHint("Gõ thử ở đây (Telex: vieetj → việt)");
        c1.addView(test, lpTop(8));

        // --- 2. giao diện
        LinearLayout c2 = card(page, "2. Giao diện bàn phím");
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Themes.NAMES.length; i++) {
            final int idx = i;
            TextView t = text(Themes.NAMES[i], 14, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(px(6), px(10), px(6), px(10));
            t.setOnClickListener(v -> {
                prefs.edit().putInt("theme", idx).apply();
                refreshThemeChips();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
            lp.setMargins(px(3), 0, px(3), 0);
            chips.addView(t, lp);
            themeChips[i] = t;
        }
        c2.addView(chips);
        refreshThemeChips();

        // --- 3. tạo sticker
        LinearLayout c3 = card(page, "3. Tạo sticker");
        TextView pick = button("Chọn ảnh từ máy");
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Chọn ảnh"), REQ_PICK);
        });
        c3.addView(pick);
        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackgroundColor(0xFFE6E8EC);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(px(180), px(180));
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.topMargin = px(10);
        c3.addView(preview, plp);

        caption = new EditText(this);
        caption.setHint("Chữ trên sticker (không bắt buộc)");
        caption.setSingleLine(true);
        caption.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                renderPreview();
            }
        });
        c3.addView(caption, lpTop(6));

        LinearLayout opts = new LinearLayout(this);
        opts.setOrientation(LinearLayout.HORIZONTAL);
        btnPos = button("Chữ: dưới");
        btnPos.setOnClickListener(v -> {
            captionTop = !captionTop;
            btnPos.setText(captionTop ? "Chữ: trên" : "Chữ: dưới");
            renderPreview();
        });
        btnRound = button("Bo góc: bật");
        btnRound.setOnClickListener(v -> {
            rounded = !rounded;
            btnRound.setText(rounded ? "Bo góc: bật" : "Bo góc: tắt");
            renderPreview();
        });
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ol.setMargins(px(3), 0, px(3), 0);
        opts.addView(btnPos, ol);
        opts.addView(btnRound, ol);
        c3.addView(opts, lpTop(8));

        TextView save = button("Lưu sticker");
        save.setBackground(roundBg(0xFF188038, 10));
        save.setOnClickListener(v -> saveSticker());
        c3.addView(save, lpTop(8));

        // --- 4. sticker của tôi
        LinearLayout c4 = card(page, "Sticker của tôi (bấm giữ để xoá)");
        myStickers = new GridLayout(this);
        myStickers.setColumnCount(4);
        c4.addView(myStickers);

        // --- 5. đổi kiểu chữ
        LinearLayout c5 = card(page, "4. Đổi kiểu chữ (bấm vào dòng để sao chép)");
        styleInput = new EditText(this);
        styleInput.setText("Xin chào OffMoji");
        styleInput.setSingleLine(true);
        styleInput.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                refreshStyles();
            }
        });
        c5.addView(styleInput);
        styleList = new LinearLayout(this);
        styleList.setOrientation(LinearLayout.VERTICAL);
        c5.addView(styleList, lpTop(6));
        refreshStyles();

        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshMyStickers();
    }

    private LinearLayout.LayoutParams lpTop(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = px(topDp);
        return lp;
    }

    private GradientDrawable roundBg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(px(radiusDp));
        return g;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF1B1E24);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s) {
        TextView t = text(s, 15, true);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setPadding(px(12), px(12), px(12), px(12));
        t.setBackground(roundBg(ACCENT, 10));
        return t;
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(px(14), px(14), px(14), px(14));
        c.setBackground(roundBg(Color.WHITE, 14));
        c.addView(text(heading, 17, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = px(14);
        parent.addView(c, lp);
        return c;
    }

    // ------------------------------------------------------------------ trạng thái bàn phím

    private boolean isEnabled() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm == null) return false;
        for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
            if (i.getPackageName().equals(getPackageName())) return true;
        }
        return false;
    }

    private boolean isSelected() {
        String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return cur != null && cur.startsWith(getPackageName() + "/");
    }

    private void refreshStatus() {
        if (isSelected()) {
            status.setText("✅ OffMoji đang là bàn phím của bạn.");
        } else if (isEnabled()) {
            status.setText("☑️ Đã bật. Bấm bước 2 để chọn OffMoji.");
        } else {
            status.setText("⬜ Chưa bật. Bấm bước 1, gạt công tắc OffMoji.");
        }
    }

    private void refreshThemeChips() {
        int cur = prefs.getInt("theme", 0);
        for (int i = 0; i < themeChips.length; i++) {
            boolean on = i == cur;
            themeChips[i].setBackground(roundBg(on ? ACCENT : 0xFFE6E8EC, 10));
            themeChips[i].setTextColor(on ? Color.WHITE : 0xFF1B1E24);
        }
    }

    // ------------------------------------------------------------------ tạo sticker

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Bitmap b = loadBitmap(data.getData());
            if (b == null) {
                Toast.makeText(this, "Không mở được ảnh này", Toast.LENGTH_SHORT).show();
                return;
            }
            srcBitmap = b;
            renderPreview();
        }
    }

    private Bitmap loadBitmap(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();

            int sample = 1;
            while (o.outWidth / sample > 1400 || o.outHeight / sample > 1400) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();
            if (bmp == null) return null;

            int orientation = ExifInterface.ORIENTATION_NORMAL;
            try {
                in = getContentResolver().openInputStream(uri);
                if (in != null) {
                    orientation = new ExifInterface(in).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    in.close();
                }
            } catch (Exception ignored) {
                // ảnh không có EXIF: bỏ qua
            }
            Matrix m = new Matrix();
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) m.postRotate(90);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) m.postRotate(180);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) m.postRotate(270);
            if (!m.isIdentity()) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    private Bitmap renderSticker() {
        final int size = 512;
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        // cắt vuông ở giữa
        float s = Math.max((float) size / srcBitmap.getWidth(), (float) size / srcBitmap.getHeight());
        float dw = srcBitmap.getWidth() * s;
        float dh = srcBitmap.getHeight() * s;
        RectF dst = new RectF((size - dw) / 2f, (size - dh) / 2f, (size + dw) / 2f, (size + dh) / 2f);
        c.drawBitmap(srcBitmap, null, dst, p);

        if (rounded) {
            Bitmap mask = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            new Canvas(mask).drawRoundRect(new RectF(0, 0, size, size), 72, 72, new Paint(Paint.ANTI_ALIAS_FLAG));
            Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
            mp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(mask, 0, 0, mp);
        }

        String t = caption.getText().toString().trim();
        if (!t.isEmpty()) {
            Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            tp.setTextAlign(Paint.Align.CENTER);
            float sz = 84;
            tp.setTextSize(sz);
            while (tp.measureText(t) > 470 && sz > 20) {
                sz -= 2;
                tp.setTextSize(sz);
            }
            float y = captionTop ? 18 - tp.ascent() : size - 22 - tp.descent();
            Paint stroke = new Paint(tp);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(sz / 6f);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK);
            tp.setColor(Color.WHITE);
            c.drawText(t, size / 2f, y, stroke);
            c.drawText(t, size / 2f, y, tp);
        }
        return out;
    }

    private void renderPreview() {
        if (srcBitmap == null) return;
        preview.setImageBitmap(renderSticker());
    }

    private void saveSticker() {
        if (srcBitmap == null) {
            Toast.makeText(this, "Hãy chọn ảnh trước", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            File f = new File(StickerStore.dir(this), "stk_" + System.currentTimeMillis() + ".png");
            FileOutputStream out = new FileOutputStream(f);
            renderSticker().compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(this, "Đã lưu! Mở bàn phím OffMoji → biểu tượng 🖼 để gửi.", Toast.LENGTH_LONG).show();
            refreshMyStickers();
        } catch (Exception e) {
            Toast.makeText(this, "Lưu thất bại: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void refreshMyStickers() {
        if (myStickers == null) return;
        myStickers.removeAllViews();
        File[] files = StickerStore.list(this);
        int cell = (getResources().getDisplayMetrics().widthPixels - px(28 + 28)) / 4;
        for (File f : files) {
            final File file = f;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(3), px(3), px(3), px(3));
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            Bitmap b = BitmapFactory.decodeFile(file.getPath(), o);
            if (b != null) iv.setImageBitmap(b);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Xoá sticker này?")
                        .setPositiveButton("Xoá", (d, w) -> {
                            file.delete();
                            refreshMyStickers();
                        })
                        .setNegativeButton("Giữ lại", null)
                        .show();
                return true;
            });
            myStickers.addView(iv);
        }
        if (files.length == 0) {
            TextView none = text("Chưa có sticker nào.", 14, false);
            none.setTextColor(0xFF777D88);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.columnSpec = GridLayout.spec(0, 4);
            none.setLayoutParams(lp);
            myStickers.addView(none);
        }
    }

    // ------------------------------------------------------------------ đổi kiểu chữ

    private void refreshStyles() {
        if (styleList == null) return;
        styleList.removeAllViews();
        String in = styleInput.getText().toString();
        for (FontStyles.Style st : FontStyles.ALL) {
            final String out = FontStyles.apply(st, in);
            TextView t = text(out + "\n" + st.name, 18, false);
            t.setPadding(px(10), px(8), px(10), px(8));
            t.setBackground(roundBg(0xFFF1F3F6, 8));
            t.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("offmoji", out));
                Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show();
            });
            styleList.addView(t, lpTop(6));
        }
    }

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }
}
