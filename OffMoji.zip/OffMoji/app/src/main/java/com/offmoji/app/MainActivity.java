package com.offmoji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    // ---- chỉnh ở đây nếu cần
    private static final String FEEDBACK_URL = "http://facebook.com/TruongAlone";
    private static final String BANK_NUMBER = "220011026789";

    private static final int REQ_PICK = 1;
    private static final int REQ_BG = 3;
    private static final int REQ_SND_KNOCK = 4;
    private static final int REQ_SND_BELL = 5;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int ACCENT = 0xFF1A73E8;

    private SharedPreferences prefs;
    private float dp = 1f;
    private SoundFx sfx;

    private FrameLayout content;
    private final View[] pages = new View[4];
    private final TextView[] tabBtns = new TextView[4];

    // tab giao diện
    private TextView status;
    private ImageView bgPreview;
    private TextView bgInfo;

    // tab sticker
    private ImageView preview;
    private EditText caption;
    private TextView btnPos;
    private TextView btnRound;
    private GridLayout myStickers;
    private Bitmap square;
    private boolean captionTop = false;
    private boolean rounded = true;

    private int px(float d) {
        return Math.round(d * dp);
    }

    // ------------------------------------------------------------------ khung + tab dưới cùng

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("offmoji", MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;

        LinearLayout rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(0xFFF1F3F6);

        content = new FrameLayout(this);
        rootView.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        pages[0] = buildThemeTab();
        pages[1] = buildStickerTab();
        pages[2] = buildFxTab();
        pages[3] = buildInfoTab();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.WHITE);
        bar.setElevation(px(8));
        String[] names = {"Giao diện", "Sticker", "Hiệu ứng & âm", "Thông tin"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            t.setPadding(px(2), px(14), px(2), px(14));
            t.setOnClickListener(v -> selectTab(idx));
            bar.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
            tabBtns[i] = t;
        }
        rootView.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        setContentView(rootView);
        selectTab(0);
    }

    private void selectTab(int idx) {
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            tabBtns[i].setTextColor(i == idx ? ACCENT : 0xFF6B7280);
            tabBtns[i].setTypeface(i == idx ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshMyStickers();
        refreshBgPreview();
    }

    @Override
    protected void onDestroy() {
        if (sfx != null) sfx.release();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ tiện ích giao diện

    private LinearLayout newPage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(px(14), px(18), px(14), px(24));
        return page;
    }

    private ScrollView wrap(LinearLayout page) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF1F3F6);
        sv.addView(page, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    private LinearLayout.LayoutParams lpTop(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = px(topDp);
        return lp;
    }

    private GradientDrawable roundBg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(px(radiusDp));
        return g;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF1B1E24);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s) {
        TextView t = text(s, 15, true);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setPadding(px(12), px(12), px(12), px(12));
        t.setBackground(roundBg(ACCENT, 10));
        return t;
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(px(14), px(14), px(14), px(14));
        c.setBackground(roundBg(Color.WHITE, 14));
        c.addView(text(heading, 17, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = px(14);
        parent.addView(c, lp);
        return c;
    }

    private void styleChip(TextView t, boolean on) {
        t.setBackground(roundBg(on ? ACCENT : 0xFFE6E8EC, 10));
        t.setTextColor(on ? Color.WHITE : 0xFF1B1E24);
    }

    private HorizontalScrollView chips(final String[] names, int selected, final IntConsumer onPick) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] cs = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = text(names[i], 14, false);
            t.setPadding(px(14), px(9), px(14), px(9));
            t.setGravity(Gravity.CENTER);
            styleChip(t, i == selected);
            t.setOnClickListener(v -> {
                for (int k = 0; k < cs.length; k++) styleChip(cs[k], k == idx);
                onPick.accept(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(px(3), px(3), px(3), px(3));
            row.addView(t, lp);
            cs[i] = t;
        }
        hs.addView(row);
        return hs;
    }

    private void addSeek(LinearLayout parent, String label, final String key, int def) {
        final TextView lbl = text(label + ": " + prefs.getInt(key, def) + "%", 14, false);
        parent.addView(lbl, lpTop(12));
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(prefs.getInt(key, def));
        final String name = label;
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = Math.max(5, progress);
                prefs.edit().putInt(key, v).apply();
                lbl.setText(name + ": " + v + "%");
            }
        });
        parent.addView(sb, lpTop(2));
    }

    // ------------------------------------------------------------------ tab 1: giao diện

    private View buildThemeTab() {
        LinearLayout page = newPage();
        page.addView(text("OffMoji", 28, true));
        TextView sub = text("Bàn phím gõ Telex/VNI, emoji, sticker, hiệu ứng. Chạy hoàn toàn offline, "
                + "app không xin quyền Internet.", 14, false);
        sub.setTextColor(0xFF555B66);
        page.addView(sub, lpTop(4));

        LinearLayout c1 = card(page, "Bật bàn phím");
        status = text("", 14, false);
        c1.addView(status);
        TextView b1 = button("Bước 1: Bật OffMoji trong cài đặt");
        b1.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        c1.addView(b1, lpTop(8));
        TextView b2 = button("Bước 2: Chọn OffMoji làm bàn phím");
        b2.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        c1.addView(b2, lpTop(8));
        EditText test = new EditText(this);
        test.setHint("Chạm vào đây để gõ thử (Telex: vieetj → việt)");
        c1.addView(test, lpTop(8));

        LinearLayout cIm = card(page, "Kiểu gõ tiếng Việt");
        cIm.addView(chips(new String[]{"Telex", "VNI", "Tắt (EN)"}, prefs.getInt("im_mode", 0),
                idx -> prefs.edit().putInt("im_mode", idx).apply()), lpTop(6));
        TextView imHint = text("Telex: aa→â, aw→ă, dd→đ, s f r x j = dấu.\nVNI: a6→â, a8→ă, d9→đ, 1-5 = dấu.\n"
                + "Trên bàn phím, chạm nút Telex/VNI/EN ở thanh trên để đổi nhanh.", 13, false);
        imHint.setTextColor(0xFF777D88);
        cIm.addView(imHint, lpTop(6));
        Switch compatSw = new Switch(this);
        compatSw.setText("Chế độ tương thích (chỉ bật nếu một ứng dụng nào đó bị lỗi mất dấu)");
        compatSw.setChecked(prefs.getBoolean("compat", false));
        compatSw.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("compat", on).apply());
        cIm.addView(compatSw, lpTop(10));
        Switch uriSw = new Switch(this);
        uriSw.setText("Gõ tiếng Việt cả ở thanh địa chỉ trình duyệt (tắt nếu hay gõ địa chỉ web)");
        uriSw.setChecked(prefs.getBoolean("uri_vi", true));
        uriSw.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("uri_vi", on).apply());
        cIm.addView(uriSw, lpTop(10));

        LinearLayout c2 = card(page, "Giao diện bàn phím");
        c2.addView(chips(Themes.NAMES, prefs.getInt("theme", 0),
                idx -> prefs.edit().putInt("theme", idx).apply()), lpTop(6));
        TextView hint = text("Kính lỏng: kính 3D trong suốt. Phím nổi: phím bo tròn có bóng đổ. "
                + "Bông: phím tròn đỏ nhạt, nút chức năng đỏ đậm, đều là kính bóng.", 13, false);
        hint.setTextColor(0xFF777D88);
        c2.addView(hint, lpTop(6));

        LinearLayout c3 = card(page, "Ảnh nền & độ trong suốt");
        bgPreview = new ImageView(this);
        bgPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgPreview.setBackground(roundBg(0xFFE6E8EC, 10));
        bgPreview.setClipToOutline(true);
        c3.addView(bgPreview, new LinearLayout.LayoutParams(MATCH, px(110)));
        bgInfo = text("", 13, false);
        bgInfo.setTextColor(0xFF777D88);
        c3.addView(bgInfo, lpTop(4));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView pickBg = button("Chọn ảnh nền");
        pickBg.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Chọn ảnh nền"), REQ_BG);
        });
        TextView clearBg = button("Bỏ ảnh nền");
        clearBg.setBackground(roundBg(0xFF6B7280, 10));
        clearBg.setOnClickListener(v -> {
            new File(getFilesDir(), "bg.jpg").delete();
            prefs.edit().putBoolean("bg_on", false).putLong("bg_stamp", System.currentTimeMillis()).apply();
            refreshBgPreview();
        });
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        rl.setMargins(px(3), 0, px(3), 0);
        row.addView(pickBg, rl);
        row.addView(clearBg, rl);
        c3.addView(row, lpTop(8));

        addSeek(c3, "Độ đậm ảnh nền", "bg_alpha", 100);
        addSeek(c3, "Độ đậm phím (thấp = trong suốt hơn)", "key_alpha", 100);
        return wrap(page);
    }

    private boolean isEnabled() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm == null) return false;
        for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
            if (i.getPackageName().equals(getPackageName())) return true;
        }
        return false;
    }

    private boolean isSelected() {
        String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return cur != null && cur.startsWith(getPackageName() + "/");
    }

    private void refreshStatus() {
        if (status == null) return;
        if (isSelected()) {
            status.setText("OffMoji đang là bàn phím của bạn.");
        } else if (isEnabled()) {
            status.setText("Đã bật. Bấm bước 2 để chọn OffMoji.");
        } else {
            status.setText("Chưa bật. Bấm bước 1, gạt công tắc OffMoji.");
        }
    }

    private void refreshBgPreview() {
        if (bgPreview == null) return;
        File f = new File(getFilesDir(), "bg.jpg");
        if (prefs.getBoolean("bg_on", false) && f.exists()) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            bgPreview.setImageBitmap(BitmapFactory.decodeFile(f.getPath(), o));
            bgInfo.setText("Đang dùng ảnh nền của bạn.");
        } else {
            bgPreview.setImageBitmap(null);
            bgInfo.setText("Chưa chọn ảnh nền.");
        }
    }

    private void saveBackground(Uri uri) {
        Bitmap b = loadBitmap(uri, 1600);
        if (b == null) {
            Toast.makeText(this, "Không mở được ảnh này", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Bitmap s = b;
            if (b.getWidth() > 1080) {
                s = Bitmap.createScaledBitmap(b, 1080, Math.round(b.getHeight() * 1080f / b.getWidth()), true);
            }
            FileOutputStream o = new FileOutputStream(new File(getFilesDir(), "bg.jpg"));
            s.compress(Bitmap.CompressFormat.JPEG, 88, o);
            o.close();
            prefs.edit().putBoolean("bg_on", true).putLong("bg_stamp", System.currentTimeMillis()).apply();
            refreshBgPreview();
            Toast.makeText(this, "Đã đặt ảnh nền bàn phím", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Lưu ảnh nền thất bại", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ tab 2: sticker

    private View buildStickerTab() {
        LinearLayout page = newPage();
        page.addView(text("Sticker", 24, true));

        LinearLayout c1 = card(page, "Tạo sticker từ ảnh");
        TextView pick = button("Tải ảnh lên");
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Chọn ảnh"), REQ_PICK);
        });
        c1.addView(pick, lpTop(8));

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackgroundColor(0xFFE6E8EC);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(px(200), px(200));
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.topMargin = px(10);
        c1.addView(preview, plp);

        caption = new EditText(this);
        caption.setHint("Chữ trên sticker (không bắt buộc)");
        caption.setSingleLine(true);
        caption.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                renderPreview();
            }
        });
        c1.addView(caption, lpTop(6));

        LinearLayout opts = new LinearLayout(this);
        opts.setOrientation(LinearLayout.HORIZONTAL);
        btnPos = button("Chữ: dưới");
        btnPos.setOnClickListener(v -> {
            captionTop = !captionTop;
            btnPos.setText(captionTop ? "Chữ: trên" : "Chữ: dưới");
            renderPreview();
        });
        btnRound = button("Bo góc: bật");
        btnRound.setOnClickListener(v -> {
            rounded = !rounded;
            btnRound.setText(rounded ? "Bo góc: bật" : "Bo góc: tắt");
            renderPreview();
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        sl.setMargins(px(3), 0, px(3), 0);
        opts.addView(btnPos, sl);
        opts.addView(btnRound, sl);
        c1.addView(opts, lpTop(8));

        TextView save = button("Lưu sticker");
        save.setBackground(roundBg(0xFF188038, 10));
        save.setOnClickListener(v -> saveSticker());
        c1.addView(save, lpTop(10));

        LinearLayout c2 = card(page, "Sticker hài hước (bấm để thêm vào “của tôi”)");
        GridLayout fg = new GridLayout(this);
        fg.setColumnCount(4);
        int cell = (getResources().getDisplayMetrics().widthPixels - px(28 + 28)) / 4;
        for (int i = 0; i < FunnyData.EMOJI.length; i++) {
            final int idx = i;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(3), px(3), px(3), px(3));
            iv.setImageBitmap(StickerArt.renderFunny(i, StickerStore.FUNNY_SIZE));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnClickListener(v -> {
                saveBitmapAsSticker(StickerArt.renderFunny(idx, StickerStore.FUNNY_SIZE));
                Toast.makeText(this, "Đã thêm: " + FunnyData.CAPTION[idx], Toast.LENGTH_SHORT).show();
            });
            fg.addView(iv);
        }
        c2.addView(fg, lpTop(8));
        TextView tip = text("Các sticker này cũng có sẵn trên bàn phím: biểu tượng ảnh → “Hài hước”.", 13, false);
        tip.setTextColor(0xFF777D88);
        c2.addView(tip, lpTop(6));

        LinearLayout c3 = card(page, "Sticker của tôi (bấm giữ để xoá)");
        myStickers = new GridLayout(this);
        myStickers.setColumnCount(4);
        c3.addView(myStickers, lpTop(6));
        return wrap(page);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_PICK) {
            setSource(loadBitmap(uri, 1400));
        } else if (requestCode == REQ_BG) {
            saveBackground(uri);
        } else if (requestCode == REQ_SND_KNOCK || requestCode == REQ_SND_BELL) {
            copySound(uri, requestCode == REQ_SND_KNOCK ? "snd_knock" : "snd_bell");
        }
    }

    private Bitmap loadBitmap(Uri uri, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();

            int sample = 1;
            while (o.outWidth / sample > maxSide || o.outHeight / sample > maxSide) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();
            if (bmp == null) return null;

            int orientation = ExifInterface.ORIENTATION_NORMAL;
            try {
                in = getContentResolver().openInputStream(uri);
                if (in != null) {
                    orientation = new ExifInterface(in).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    in.close();
                }
            } catch (Exception ignored) {
                // ảnh không có EXIF
            }
            Matrix m = new Matrix();
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) m.postRotate(90);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) m.postRotate(180);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) m.postRotate(270);
            if (!m.isIdentity()) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    private void setSource(Bitmap b) {
        if (b == null) {
            Toast.makeText(this, "Không mở được ảnh này", Toast.LENGTH_SHORT).show();
            return;
        }
        square = StickerArt.cropSquare(b, 512);
        renderPreview();
    }

    private Bitmap renderSticker() {
        final int size = 512;
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawBitmap(square, 0, 0, null);
        if (rounded) {
            Bitmap mask = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            new Canvas(mask).drawRoundRect(new RectF(0, 0, size, size), 72, 72,
                    new Paint(Paint.ANTI_ALIAS_FLAG));
            Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
            mp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(mask, 0, 0, mp);
        }
        StickerArt.drawCaption(c, caption.getText().toString(), size, captionTop);
        return out;
    }

    private void renderPreview() {
        if (square == null) return;
        preview.setImageBitmap(renderSticker());
    }

    private void saveSticker() {
        if (square == null) {
            Toast.makeText(this, "Hãy tải ảnh lên trước", Toast.LENGTH_SHORT).show();
            return;
        }
        if (saveBitmapAsSticker(renderSticker())) {
            Toast.makeText(this, "Đã lưu! Mở bàn phím OffMoji → biểu tượng ảnh để gửi.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean saveBitmapAsSticker(Bitmap b) {
        try {
            File f = new File(StickerStore.dir(this), "stk_" + System.currentTimeMillis() + ".png");
            FileOutputStream out = new FileOutputStream(f);
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            refreshMyStickers();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Lưu thất bại: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void refreshMyStickers() {
        if (myStickers == null) return;
        myStickers.removeAllViews();
        File[] files = StickerStore.list(this);
        int cell = (getResources().getDisplayMetrics().widthPixels - px(28 + 28)) / 4;
        for (File f : files) {
            final File file = f;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(px(3), px(3), px(3), px(3));
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            Bitmap b = BitmapFactory.decodeFile(file.getPath(), o);
            if (b != null) iv.setImageBitmap(b);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            iv.setLayoutParams(lp);
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Xoá sticker này?")
                        .setPositiveButton("Xoá", (d, w) -> {
                            file.delete();
                            refreshMyStickers();
                        })
                        .setNegativeButton("Giữ lại", null)
                        .show();
                return true;
            });
            myStickers.addView(iv);
        }
        if (files.length == 0) {
            TextView none = text("Chưa có sticker nào.", 14, false);
            none.setTextColor(0xFF777D88);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.columnSpec = GridLayout.spec(0, 4);
            none.setLayoutParams(lp);
            myStickers.addView(none);
        }
    }

    // ------------------------------------------------------------------ tab 3: hiệu ứng & âm

    private View buildFxTab() {
        LinearLayout page = newPage();
        page.addView(text("Hiệu ứng & âm thanh", 24, true));

        LinearLayout c1 = card(page, "Hiệu ứng khi gõ");
        Switch heart = new Switch(this);
        heart.setText("Trái tim bay lên kèm chữ của phím");
        heart.setChecked(prefs.getBoolean("fx_heart", true));
        heart.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("fx_heart", on).apply());
        c1.addView(heart, lpTop(8));

        final HeartView hv = new HeartView(this);
        FrameLayout demo = new FrameLayout(this);
        demo.setBackground(roundBg(0xFF2B2D34, 12));
        TextView demoText = text("Chạm vào đây để thử", 15, false);
        demoText.setTextColor(0xFFDDDDDD);
        demoText.setGravity(Gravity.CENTER);
        demo.addView(demoText, new FrameLayout.LayoutParams(MATCH, MATCH));
        demo.addView(hv, new FrameLayout.LayoutParams(MATCH, MATCH));
        final String letters = "OFFMOJI";
        final int[] n = {0};
        demo.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                hv.spawn(e.getX(), e.getY(), String.valueOf(letters.charAt(n[0]++ % letters.length())));
                playTest(false);
            }
            return true;
        });
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, px(130));
        dlp.topMargin = px(10);
        c1.addView(demo, dlp);

        LinearLayout c2 = card(page, "Âm thanh bàn phím");
        Switch snd = new Switch(this);
        snd.setText("Bật âm thanh khi gõ");
        snd.setChecked(prefs.getBoolean("fx_sound", true));
        snd.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("fx_sound", on).apply());
        c2.addView(snd, lpTop(8));
        TextView info = text("Gõ phím: tiếng gõ mõ.  Bấm cách / Enter: tiếng chuông.", 13, false);
        info.setTextColor(0xFF777D88);
        c2.addView(info, lpTop(6));
        addSeek(c2, "Âm lượng", "sound_vol", 80);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView t1 = button("Nghe tiếng mõ");
        t1.setOnClickListener(v -> playTest(false));
        TextView t2 = button("Nghe tiếng chuông");
        t2.setOnClickListener(v -> playTest(true));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        rl.setMargins(px(3), 0, px(3), 0);
        row.addView(t1, rl);
        row.addView(t2, rl);
        c2.addView(row, lpTop(10));

        LinearLayout c3 = card(page, "Dùng file âm thanh thật của bạn");
        TextView snote = text("Mặc định app tự tạo tiếng mõ và chuông. Muốn dùng file thật (.wav, .mp3 hoặc .ogg, "
                + "nên ngắn dưới 2 giây) thì chọn ở đây.", 13, false);
        snote.setTextColor(0xFF777D88);
        c3.addView(snote, lpTop(6));
        TextView pk = button("Chọn file tiếng mõ (khi gõ phím)");
        pk.setOnClickListener(v -> pickSound(REQ_SND_KNOCK));
        c3.addView(pk, lpTop(10));
        TextView pb = button("Chọn file chuông (cách / Enter)");
        pb.setOnClickListener(v -> pickSound(REQ_SND_BELL));
        c3.addView(pb, lpTop(8));
        TextView rs = button("Dùng lại âm thanh mặc định");
        rs.setBackground(roundBg(0xFF6B7280, 10));
        rs.setOnClickListener(v -> {
            new File(getFilesDir(), "snd_knock").delete();
            new File(getFilesDir(), "snd_bell").delete();
            soundChanged();
            Toast.makeText(this, "Đã dùng lại âm thanh mặc định", Toast.LENGTH_SHORT).show();
        });
        c3.addView(rs, lpTop(8));
        return wrap(page);
    }

    private void pickSound(int req) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("audio/*");
        startActivityForResult(Intent.createChooser(i, "Chọn file âm thanh"), req);
    }

    private void copySound(Uri uri, String name) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new java.io.IOException("không mở được file");
            FileOutputStream out = new FileOutputStream(new File(getFilesDir(), name));
            byte[] buf = new byte[16384];
            long total = 0;
            int r;
            while ((r = in.read(buf)) > 0) {
                out.write(buf, 0, r);
                total += r;
            }
            out.close();
            in.close();
            soundChanged();
            String warn = total > 1500000 ? " (file hơi lớn, nên dùng file ngắn hơn)" : "";
            Toast.makeText(this, "Đã đặt âm thanh. Bấm nghe thử để kiểm tra." + warn, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Không đọc được file âm thanh", Toast.LENGTH_SHORT).show();
        }
    }

    private void soundChanged() {
        prefs.edit().putLong("snd_stamp", System.currentTimeMillis()).apply();
        if (sfx != null) {
            sfx.release();
            sfx = null;
        }
    }

    private void playTest(boolean bell) {
        if (!prefs.getBoolean("fx_sound", true)) return;
        if (sfx == null) sfx = new SoundFx(this);
        sfx.play(bell, prefs.getInt("sound_vol", 80) / 100f);
    }

    // ------------------------------------------------------------------ tab 4: thông tin

    private View buildInfoTab() {
        LinearLayout page = newPage();
        page.addView(text("Thông tin", 24, true));

        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
            // không đọc được phiên bản
        }
        LinearLayout c0 = card(page, "OffMoji " + ver);
        TextView about = text("Bàn phím gõ Telex/VNI, emoji, kiểu chữ, sticker và hiệu ứng. "
                + "Chạy hoàn toàn offline.", 14, false);
        about.setTextColor(0xFF555B66);
        c0.addView(about, lpTop(6));

        LinearLayout c1 = card(page, "Góp ý");
        TextView fb = text("Có lỗi hay ý tưởng mới? Nhắn mình trên Facebook nhé.", 14, false);
        fb.setTextColor(0xFF555B66);
        c1.addView(fb, lpTop(6));
        TextView open = button("Góp ý trên Facebook");
        open.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(FEEDBACK_URL)));
            } catch (Exception e) {
                Toast.makeText(this, "Không mở được trình duyệt", Toast.LENGTH_SHORT).show();
            }
        });
        c1.addView(open, lpTop(10));
        TextView url = text(FEEDBACK_URL, 13, false);
        url.setTextColor(0xFF777D88);
        c1.addView(url, lpTop(6));

        LinearLayout c2 = card(page, "Gói Bim Bim");
        TextView msg = text("Tiếc gì 1 gói bim bim, cho là lấy.\nXin gởi về:", 15, false);
        c2.addView(msg, lpTop(6));
        TextView bank = text("Ngân hàng MB: " + BANK_NUMBER, 18, true);
        bank.setPadding(px(12), px(12), px(12), px(12));
        bank.setBackground(roundBg(0xFFF1F3F6, 10));
        bank.setGravity(Gravity.CENTER);
        c2.addView(bank, lpTop(10));
        TextView copy = button("Sao chép số tài khoản");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("MB", BANK_NUMBER));
            Toast.makeText(this, "Đã sao chép số tài khoản", Toast.LENGTH_SHORT).show();
        });
        c2.addView(copy, lpTop(10));
        return wrap(page);
    }

    // ------------------------------------------------------------------ lớp phụ

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }
}
