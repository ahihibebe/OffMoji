# Activity/Service/Provider khai báo trong AndroidManifest được giữ tự động.
# App không dùng reflection (chỉ getIdentifier cho res/raw, đã giữ bằng res/raw/keep.xml).
-dontwarn androidx.**
