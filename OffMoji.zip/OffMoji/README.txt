OffMoji - ban phim emoji / kieu chu / sticker ca nhan, chay hoan toan offline (khong xin quyen INTERNET).

Build APK: xem file build-offmoji.yml (dat vao .github/workflows/ trong repo GitHub),
va dat OffMoji.zip o thu muc goc cua repo.
