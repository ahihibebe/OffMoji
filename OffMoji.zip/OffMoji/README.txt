TKey - ban phim Telex/VNI, emoji, sticker, hieu ung, chay hoan toan offline (khong xin quyen nao).

AM THANH THAT:
- Cach 1 (trong app): tab "Hieu ung & am" -> "Dung file am thanh that cua ban".
- Cach 2 (dong goi san trong APK): chep file vao app/src/main/res/raw/ voi ten
  knock.wav (tieng mo) va bell.wav (tieng chuong). Duoi file co the la .wav .mp3 .ogg
  (moi ten chi duoc 1 file). Neu khong co, app dung am tu tong hop.

Build APK: xem build-offmoji.yml (dat vao .github/workflows/ trong repo GitHub),
va dat TKey.zip o thu muc goc cua repo. Ban release da bat R8 + thu gon tai nguyen de APK nho nhat.
